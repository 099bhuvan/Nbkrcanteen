# NBKRCN Smart Canteen — GitHub + Netlify + Supabase

## GitHub
Upload the contents of this ZIP to a new GitHub repository. Do NOT upload `.env` files containing secrets.

## Supabase
The app is preconfigured for the NBKRCN Supabase project using the browser-safe publishable key. Run `supabase_schema.sql` in Supabase SQL Editor if the tables are not already present.

## Netlify
Import the GitHub repository in Netlify. Build command: `npm run build`. Publish directory: `dist`.

Optional environment variables (recommended):
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

The app has safe built-in defaults for this project's URL and publishable key, so it will not show “Supabase is not configured” when deployed without Netlify variables.

## Important
Never put a Supabase service-role/secret key in the frontend. The publishable key is intended for browser use and RLS protects database rows.
