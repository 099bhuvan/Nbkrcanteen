# NBKRCN Smart Canteen

React + Vite Smart Canteen application prepared for **GitHub → Netlify → Supabase** deployment.

## Included
- Existing NBKRCN canteen UI and workflows
- Supabase browser client using the publishable key
- Supabase Auth integration for student registration/sign-in
- Cloud user profiles and orders
- Supabase menu hydration and realtime order updates
- RLS database schema in `supabase_schema.sql`
- Netlify SPA routing in `netlify.toml`
- Mobile-friendly deployment instructions in `GITHUB_NETLIFY_SETUP.md`

## Deploy
1. Upload this repository to GitHub.
2. Import the GitHub repository into Netlify.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Run `supabase_schema.sql` in Supabase SQL Editor if the tables are not already present.

The app contains safe project-specific defaults for the Supabase URL and browser publishable key. You can override them with `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` in Netlify.

Never put a Supabase service-role/secret key in this repository.
