import React, { useState, useEffect } from 'react';
import { CanteenProvider, useCanteen } from './context/CanteenContext';
import { Navbar } from './components/Navbar';
import { LandingPage } from './pages/LandingPage';
import { RegisterPage } from './pages/RegisterPage';
import { StudentDashboard } from './pages/StudentDashboard';
import { CartPage } from './pages/CartPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { OrderTrackingPage } from './pages/OrderTrackingPage';
import { OrderHistoryPage } from './pages/OrderHistoryPage';
import { StudentProfilePage } from './pages/StudentProfilePage';
import { StaffDashboard } from './pages/StaffDashboard';
import { MenuManagementPage } from './pages/MenuManagementPage';
import { AdminAnalyticsPage } from './pages/AdminAnalyticsPage';
import { AdminUsersPage } from './pages/AdminUsersPage';
import { NotFoundPage } from './pages/NotFoundPage';

import { AmazonLoginPage } from './pages/AmazonLoginPage';

function AppContent() {
  const { currentUser } = useCanteen();
  const [currentRoute, setCurrentRoute] = useState<string>(() => {
    return window.location.pathname && window.location.pathname !== '/'
      ? window.location.pathname
      : currentUser
      ? currentUser.role === 'student'
        ? '/dashboard'
        : '/staff/dashboard'
      : '/login';
  });

  const [lastConfirmedOrderId, setLastConfirmedOrderId] = useState<string | null>(null);

  // Sync with browser navigation
  useEffect(() => {
    const handlePopState = () => {
      setCurrentRoute(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (route: string) => {
    try {
      window.history.pushState({}, '', route);
    } catch {
      // In restricted iframe environments
    }
    setCurrentRoute(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Route protection
  const renderRoute = () => {
    // Unauthenticated access
    if (!currentUser) {
      if (currentRoute === '/register') {
        return <RegisterPage navigate={navigate} />;
      }
      if (currentRoute === '/landing') {
        return <LandingPage navigate={navigate} />;
      }
      if (currentRoute === '/login/staff') {
        return <AmazonLoginPage navigate={navigate} initialRole="staff" />;
      }
      if (currentRoute === '/login/student') {
        return <AmazonLoginPage navigate={navigate} initialRole="student" />;
      }
      // Default unauthenticated is the Amazon Sign-In page
      return <AmazonLoginPage navigate={navigate} initialRole="student" />;
    }

    // Authenticated routes
    switch (currentRoute) {
      case '/':
        return currentUser.role === 'student' ? (
          <StudentDashboard navigate={navigate} />
        ) : (
          <StaffDashboard navigate={navigate} />
        );

      case '/register':
        return <RegisterPage navigate={navigate} />;

      case '/login':
      case '/login/student':
        return <AmazonLoginPage navigate={navigate} initialRole="student" />;

      case '/login/staff':
        return <AmazonLoginPage navigate={navigate} initialRole="staff" />;

      // Student routes
      case '/dashboard':
        return <StudentDashboard navigate={navigate} />;

      case '/cart':
        return (
          <CartPage
            navigate={navigate}
            onOrderPlaced={(orderId) => setLastConfirmedOrderId(orderId)}
          />
        );

      case '/orders/confirm':
        return (
          <OrderConfirmationPage
            navigate={navigate}
            orderId={lastConfirmedOrderId}
          />
        );

      case '/orders/track':
        return <OrderTrackingPage navigate={navigate} />;

      case '/orders/history':
        return <OrderHistoryPage navigate={navigate} />;

      case '/profile':
        return <StudentProfilePage navigate={navigate} />;

      // Staff & Admin routes (Strictly blocked for students)
      case '/staff/dashboard':
        if (currentUser.role === 'student') {
          return <StudentDashboard navigate={navigate} />;
        }
        return <StaffDashboard navigate={navigate} />;

      case '/staff/menu':
        if (currentUser.role === 'student') {
          return <StudentDashboard navigate={navigate} />;
        }
        return <MenuManagementPage navigate={navigate} />;

      // Admin only routes
      case '/admin/analytics':
        if (currentUser.role !== 'admin') {
          return <StaffDashboard navigate={navigate} />;
        }
        return <AdminAnalyticsPage navigate={navigate} />;

      case '/admin/users':
        if (currentUser.role !== 'admin') {
          return <StaffDashboard navigate={navigate} />;
        }
        return <AdminUsersPage navigate={navigate} />;

      default:
        return <NotFoundPage navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col font-sans">
      <Navbar currentRoute={currentRoute} navigate={navigate} />
      <div className="flex-1">{renderRoute()}</div>
    </div>
  );
}

export default function App() {
  return (
    <CanteenProvider>
      <AppContent />
    </CanteenProvider>
  );
}
