export type UserRole = 'student' | 'staff' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  username?: string;
  password?: string;
  rollNumber?: string;
  department?: string;
  year?: string;
  phone?: string;
  createdAt: string;
  status?: 'active' | 'inactive';
}

export type MenuCategory = 'Meals' | 'Snacks' | 'Breakfast' | 'Beverages' | 'Combos';

export type AvailabilityStatus = 'available' | 'limited' | 'out_of_stock';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: MenuCategory;
  isVeg: boolean;
  availability: AvailabilityStatus;
  stockQuantity: number;
  prepTimeMinutes: number;
  rating?: number;
  iconType: 'dosa' | 'samosa' | 'biryani' | 'chai' | 'coffee' | 'thali' | 'sandwich' | 'curd_rice' | 'combo' | 'juice';
  accentColor: string;
  imageUrl?: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  specialInstructions?: string;
}

export type OrderStatus = 'placed' | 'accepted' | 'preparing' | 'ready' | 'collected' | 'rejected' | 'cancelled';

export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  specialInstructions?: string;
}

export interface Order {
  id: string;
  tokenNumber: string; // e.g. "NBK-4829"
  studentId: string;
  studentName: string;
  studentRoll: string;
  studentEmail: string;
  studentDept?: string;
  studentYear?: string;
  studentPhone?: string;
  items: OrderItem[];
  subtotal: number;
  packagingFee: number;
  total: number;
  status: OrderStatus;
  scheduledPickupTime: string;
  estimatedReadyMinutes: number;
  estimatedReadyAt: string; // ISO string
  paymentMethod: 'UPI' | 'Cash';
  paymentStatus: 'paid' | 'pay_at_counter' | 'pending';
  upiId?: string;
  upiTransactionRef?: string;
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
  rejectionReason?: string;
  cancellationReason?: string;
}
