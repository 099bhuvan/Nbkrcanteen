import React, { useState, useEffect } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { UserRole } from '../types';
import { CanteenUPIQRCode } from '../components/CanteenUPIQRCode';
import {
  AlertCircle,
  ChevronRight,
  ChevronDown,
  Info,
  CheckCircle2,
  Lock,
  GraduationCap,
  ChefHat,
  ArrowRight,
  ArrowLeft,
  QrCode,
  X,
  Sparkles,
  ShieldCheck,
  Check,
  UtensilsCrossed
} from 'lucide-react';

interface AmazonLoginPageProps {
  navigate: (route: string) => void;
  initialRole?: UserRole;
}

// Realistic curated photography assets for customer food dining & staff kitchen
const CUSTOMER_IMAGE =
  'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80';
const STAFF_IMAGE =
  'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=900&q=80';

export const AmazonLoginPage: React.FC<AmazonLoginPageProps> = ({
  navigate,
  initialRole = 'student',
}) => {
  const { login, loginAsPreset } = useCanteen();

  // Primary Page Step:
  // Step 1 = Show Options (Customer vs Staff)
  // Step 2 = Show the Sign-In Form for the selected option
  const [pageStep, setPageStep] = useState<1 | 2>(1);

  // Active role option: 'student' (Customer) or 'staff' (Canteen staff)
  const [role, setRole] = useState<UserRole>(initialRole);

  // Form Step within Step 2: 1 = identifier, 2 = password
  const [formStep, setFormStep] = useState<1 | 2>(1);
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // UI helpers
  const [errorMessage, setErrorMessage] = useState('');
  const [helpOpen, setHelpOpen] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [customerImgError, setCustomerImgError] = useState(false);
  const [staffImgError, setStaffImgError] = useState(false);

  // When user selects an option in Step 1, advance to Step 2
  const handleSelectOption = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setFormStep(1);
    setIdentifier('');
    setPassword('');
    setErrorMessage('');
    setPageStep(2);
  };

  // Back to Step 1 (Options)
  const handleBackToOptions = () => {
    setPageStep(1);
    setFormStep(1);
    setIdentifier('');
    setPassword('');
    setErrorMessage('');
  };

  // Form Step 1: Validate username / email / roll
  const handleContinueForm = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const trimmed = identifier.trim();
    if (!trimmed) {
      setErrorMessage(
        role === 'staff'
          ? 'Enter your staff username'
          : 'Enter your unique student username, college email, or roll number'
      );
      return;
    }

    if (
      role === 'staff' &&
      trimmed.toLowerCase() !== 'canteen' &&
      trimmed.toLowerCase() !== 'canteen@nbkrcn.edu.in'
    ) {
      setErrorMessage(
        'Invalid staff username. Authorized canteen staff username is "canteen".'
      );
      return;
    }

    // Advance to password input
    setFormStep(2);
  };

  // Form Step 2: Final Sign in
  const handleFinalSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!password.trim()) {
      setErrorMessage(
        role === 'staff'
          ? 'Enter your staff password'
          : 'Enter your student account password'
      );
      return;
    }

    const result = login(identifier, password, role);
    if (result.success) {
      if (role === 'student') {
        navigate('/dashboard');
      } else {
        navigate('/staff/dashboard');
      }
    } else {
      setErrorMessage(
        result.message || 'There was a problem. Invalid credentials.'
      );
    }
  };

  // 1-Click Fast Preset Login
  const handleQuickDemoLogin = (targetRole: UserRole) => {
    loginAsPreset(targetRole);
    if (targetRole === 'student') {
      navigate('/dashboard');
    } else if (targetRole === 'staff') {
      navigate('/staff/dashboard');
    } else {
      navigate('/admin/analytics');
    }
  };

  return (
    <div className="min-h-screen bg-stone-100/70 flex flex-col justify-between text-stone-900 font-sans selection:bg-[#F3A847] selection:text-black">
      {/* Top Identity Bar */}
      <div className="w-full">
        <div className="bg-stone-900 text-stone-300 px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-2 border-b border-stone-800">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium text-stone-200">
              NBKR Institute of Science & Technology · Central Campus Food Court
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowQRModal(true)}
              className="text-orange-400 hover:text-orange-300 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>Counter UPI QR (7702479214@fam)</span>
            </button>
          </div>
        </div>

        {/* Amazon-style Brand Header */}
        <div className="pt-6 sm:pt-8 pb-3 px-4 flex flex-col items-center">
          <button
            onClick={() => {
              setPageStep(1);
              navigate('/');
            }}
            className="cursor-pointer group focus-visible:outline-hidden text-center"
            title="NBKRCN Smart Canteen Home"
          >
            <div className="flex items-center justify-center gap-1.5 select-none">
              <span className="font-heading font-black text-3xl sm:text-4xl tracking-tighter text-stone-900">
                nbkrcn
              </span>
              <span className="text-xs font-bold text-[#E77600] self-start mt-1">
                .in
              </span>
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider ml-1 px-1.5 py-0.5 rounded bg-stone-200">
                canteen
              </span>
            </div>
            {/* Amazon Curved Smile Arc Vector */}
            <svg
              className="w-28 sm:w-32 h-4 -mt-1 mx-auto text-[#FF9900]"
              viewBox="0 0 120 18"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M4 8 C40 18 80 18 116 6"
                stroke="#FF9900"
                strokeWidth="3.2"
                strokeLinecap="round"
              />
              <path d="M109 4 L117 7 L114 13 Z" fill="#FF9900" />
            </svg>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-4xl w-full mx-auto px-4 py-4 flex flex-col items-center">
        {/* Amazon-style Alert Banner if Error */}
        {errorMessage && (
          <div className="w-full max-w-xl mb-5 p-4 border border-[#CC0C39] bg-white rounded-xl flex items-start gap-3 shadow-xs animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 text-[#CC0C39] shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-[#CC0C39] leading-tight">
                There was a problem
              </h4>
              <p className="text-xs text-stone-700 mt-1 leading-normal">
                {errorMessage}
              </p>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 1: SHOW THE OPTIONS (CUSTOMER vs STAFF) WITH REALISTIC IMAGES        */}
        {/* ========================================================================= */}
        {pageStep === 1 && (
          <div className="w-full max-w-3xl space-y-6 animate-in fade-in zoom-in-98 duration-200">
            {/* Step 1 Indicator & Title */}
            <div className="text-center space-y-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-800 text-xs font-bold uppercase tracking-wider">
                Step 1 of 2: Select Your Portal
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight">
                Welcome to NBKRCN Smart Canteen
              </h2>
              <p className="text-xs sm:text-sm text-stone-500 max-w-lg mx-auto">
                Please select your account type below to continue to sign in.
              </p>
            </div>

            {/* The Two Option Cards Side-by-Side */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
              {/* OPTION 1: CUSTOMER (STUDENT & CAMPUS DINERS) */}
              <div
                onClick={() => handleSelectOption('student')}
                className="group relative overflow-hidden rounded-2xl border-2 border-stone-200 hover:border-orange-500 bg-white shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col"
              >
                {/* Realistic Food Photography Header */}
                <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-stone-900">
                  {!customerImgError ? (
                    <img
                      src={CUSTOMER_IMAGE}
                      alt="Authentic Indian Canteen Food Dosa and Thali"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                      onError={() => setCustomerImgError(true)}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center p-4">
                      <UtensilsCrossed className="w-12 h-12 text-white/80" />
                    </div>
                  )}

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                  {/* Badge */}
                  <div className="absolute top-3.5 left-3.5 flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-600 text-white text-xs font-bold shadow-md">
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>Option 1 · Customer</span>
                  </div>

                  {/* Card Title on Image */}
                  <div className="absolute bottom-3.5 left-3.5 right-3.5 text-white">
                    <h3 className="font-heading font-bold text-xl leading-tight">
                      Customer / Student
                    </h3>
                    <p className="text-xs text-stone-200 mt-0.5">
                      Campus dining, live food menu & digital tokens
                    </p>
                  </div>
                </div>

                {/* Card Description & Action */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <ul className="text-xs text-stone-600 space-y-2">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
                      <span>Browse breakfast, hot meals, snacks & beverages</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
                      <span>Live dish stock availability & pre-orders</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
                      <span>Digital pickup tokens to skip counter waiting lines</span>
                    </li>
                  </ul>

                  {/* Selection Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectOption('student');
                    }}
                    className="w-full py-2.5 px-4 bg-[#FFD814] hover:bg-[#F7CA00] active:bg-[#F0B800] text-stone-950 font-bold text-xs rounded-xl shadow-xs border border-[#FCD200] transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Continue as Customer</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* OPTION 2: STAFF (CANTEEN & KITCHEN OPERATIONS) */}
              <div
                onClick={() => handleSelectOption('staff')}
                className="group relative overflow-hidden rounded-2xl border-2 border-stone-200 hover:border-emerald-600 bg-white shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col"
              >
                {/* Realistic Chef Photography Header */}
                <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-stone-900">
                  {!staffImgError ? (
                    <img
                      src={STAFF_IMAGE}
                      alt="Professional Canteen Chef preparing food at kitchen station"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                      onError={() => setStaffImgError(true)}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-tr from-emerald-700 to-teal-600 flex items-center justify-center p-4">
                      <ChefHat className="w-12 h-12 text-white/80" />
                    </div>
                  )}

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                  {/* Badge */}
                  <div className="absolute top-3.5 left-3.5 flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-md">
                    <ChefHat className="w-3.5 h-3.5" />
                    <span>Option 2 · Staff</span>
                  </div>

                  {/* Card Title on Image */}
                  <div className="absolute bottom-3.5 left-3.5 right-3.5 text-white">
                    <h3 className="font-heading font-bold text-xl leading-tight">
                      Canteen Staff
                    </h3>
                    <p className="text-xs text-stone-200 mt-0.5">
                      Station counter, kitchen queue & token caller
                    </p>
                  </div>
                </div>

                {/* Card Description & Action */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <ul className="text-xs text-stone-600 space-y-2">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
                      <span>Live kitchen order queue with audio chime bell</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
                      <span>Update order status (Preparing, Ready, Collected)</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
                      <span>Authorized kitchen staff and station operators only</span>
                    </li>
                  </ul>

                  {/* Selection Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectOption('staff');
                    }}
                    className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Continue as Staff</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Canteen Counter UPI QR Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setShowQRModal(true)}
                className="w-full py-3 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-2xl shadow-sm transition-all flex items-center justify-between cursor-pointer group border border-stone-700"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-orange-600 text-white">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-white group-hover:text-orange-400 transition-colors">
                      Canteen Counter UPI QR Code
                    </p>
                    <p className="text-[11px] text-stone-400">
                      Scan to pay at counter · 7702479214@fam (kull bhuvan)
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-white transition-colors" />
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 2: SHOW SIGN-IN FORM FOR SELECTED OPTION (AMAZON STYLE)              */}
        {/* ========================================================================= */}
        {pageStep === 2 && (
          <div className="w-full max-w-[420px] space-y-4 animate-in fade-in zoom-in-98 duration-200">
            {/* Back to Step 1 Button */}
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleBackToOptions}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white px-3 py-1.5 rounded-lg border border-stone-200 shadow-2xs hover:bg-stone-50 cursor-pointer transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Change Account Option</span>
              </button>

              <span className="text-xs font-semibold text-stone-500">
                Step 2 of 2
              </span>
            </div>

            {/* Amazon-style Sign-In Card */}
            <div className="w-full bg-white border border-stone-300 rounded-2xl p-6 sm:p-7 shadow-xs">
              {/* Header with chosen role badge */}
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-normal text-stone-900 tracking-tight">
                  {role === 'student' ? 'Customer Sign In' : 'Staff Station Sign In'}
                </h1>

                <span
                  className={`text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                    role === 'student'
                      ? 'bg-orange-50 text-orange-700 border border-orange-200'
                      : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  }`}
                >
                  {role === 'student' ? (
                    <>
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>Customer</span>
                    </>
                  ) : (
                    <>
                      <ChefHat className="w-3.5 h-3.5" />
                      <span>Staff</span>
                    </>
                  )}
                </span>
              </div>

              {/* Confidential notice for staff (No credentials exposed) */}
              {role === 'staff' && (
                <div className="mb-4 p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs flex items-center gap-2 text-stone-600">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Restricted: Enter your authorized canteen staff credentials.</span>
                </div>
              )}

              {/* ---------------- FORM STEP 1: IDENTIFIER ---------------- */}
              {formStep === 1 && (
                <form onSubmit={handleContinueForm} className="space-y-4">
                  <div>
                    <label
                      htmlFor="identifierInput"
                      className="block text-xs font-bold text-stone-900 mb-1"
                    >
                      {role === 'student'
                        ? 'Unique username, college email, or roll number'
                        : 'Staff Username'}
                    </label>
                    <input
                      id="identifierInput"
                      type="text"
                      autoFocus
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder={
                        role === 'student'
                          ? 'e.g. arjun_sharma or 21NB1A0542'
                          : 'Enter staff username'
                      }
                      className="w-full px-3 py-2 text-sm rounded-lg border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                    />
                    <p className="text-[11px] text-stone-500 mt-1">
                      {role === 'student'
                        ? 'Students use their unique username created during registration'
                        : 'Staff members use their authorized station username'}
                    </p>
                  </div>

                  {/* Amazon Amber Continue Button */}
                  <button
                    type="submit"
                    className="w-full py-2.5 px-3 text-sm font-semibold text-stone-900 bg-[#FFD814] hover:bg-[#F7CA00] active:bg-[#F0B800] border border-[#FCD200] rounded-xl shadow-xs transition-colors cursor-pointer text-center"
                  >
                    Continue
                  </button>

                  {/* Legal Notice */}
                  <p className="text-[11px] text-stone-600 leading-normal pt-1">
                    By continuing, you agree to NBKRCN Canteen's{' '}
                    <a
                      href="#conditions"
                      className="text-[#007185] hover:text-[#C7511F] hover:underline"
                    >
                      Conditions of Use
                    </a>{' '}
                    and{' '}
                    <a
                      href="#privacy"
                      className="text-[#007185] hover:text-[#C7511F] hover:underline"
                    >
                      Privacy Notice
                    </a>
                    .
                  </p>

                  {/* Amazon Accordion: Need Help? */}
                  <div className="pt-2 border-t border-stone-200">
                    <button
                      type="button"
                      onClick={() => setHelpOpen(!helpOpen)}
                      className="text-xs text-[#007185] hover:text-[#C7511F] hover:underline flex items-center gap-1 cursor-pointer font-medium"
                    >
                      {helpOpen ? (
                        <ChevronDown className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5" />
                      )}
                      <span>Need help?</span>
                    </button>

                    {helpOpen && (
                      <div className="mt-2 pl-4 space-y-1.5 text-xs text-[#007185]">
                        <p>
                          <button
                            type="button"
                            onClick={() =>
                              alert(
                                'Password reset link sent to your registered contact.'
                              )
                            }
                            className="hover:text-[#C7511F] hover:underline cursor-pointer text-left"
                          >
                            Forgot your password?
                          </button>
                        </p>
                        <p>
                          <button
                            type="button"
                            onClick={() =>
                              alert(
                                'For login support, please visit Canteen Counter 1 or IT Administration.'
                              )
                            }
                            className="hover:text-[#C7511F] hover:underline cursor-pointer text-left"
                          >
                            Other issues with Sign-In
                          </button>
                        </p>
                      </div>
                    )}
                  </div>
                </form>
              )}

              {/* ---------------- FORM STEP 2: PASSWORD ---------------- */}
              {formStep === 2 && (
                <form
                  onSubmit={handleFinalSignIn}
                  className="space-y-4 animate-in fade-in duration-150"
                >
                  {/* Account display with Change link */}
                  <div className="flex items-center justify-between text-xs pb-1 border-b border-stone-100">
                    <div className="flex items-center gap-1.5 text-stone-800 font-medium truncate max-w-[260px]">
                      <span className="text-stone-400">Account:</span>
                      <span className="font-bold">{identifier}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setFormStep(1);
                        setErrorMessage('');
                      }}
                      className="text-[#007185] hover:text-[#C7511F] hover:underline font-semibold cursor-pointer shrink-0"
                    >
                      Change
                    </button>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label
                        htmlFor="passwordInput"
                        className="block text-xs font-bold text-stone-900"
                      >
                        {role === 'staff' ? 'Staff Password' : 'Password'}
                      </label>
                      <button
                        type="button"
                        onClick={() =>
                          alert(
                            'Password reset assistance requested. Please contact Canteen Admin.'
                          )
                        }
                        className="text-xs text-[#007185] hover:text-[#C7511F] hover:underline cursor-pointer"
                      >
                        Forgot your password?
                      </button>
                    </div>
                    <input
                      id="passwordInput"
                      type="password"
                      autoFocus
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                    />
                  </div>

                  {/* Amazon Sign-in Amber Button */}
                  <button
                    type="submit"
                    className="w-full py-2.5 px-3 text-sm font-semibold text-stone-900 bg-[#FFD814] hover:bg-[#F7CA00] active:bg-[#F0B800] border border-[#FCD200] rounded-xl shadow-xs transition-colors cursor-pointer text-center"
                  >
                    {role === 'student' ? 'Sign in as Customer' : 'Sign in to Staff Station'}
                  </button>

                  {/* Keep me signed in Checkbox */}
                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-2 text-xs text-stone-800 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="rounded text-[#E77600] focus:ring-[#E77600] border-stone-400"
                      />
                      <span>Keep me signed in.</span>
                    </label>

                    <button
                      type="button"
                      onClick={() => setShowDetailsModal(true)}
                      className="text-xs text-[#007185] hover:text-[#C7511F] hover:underline cursor-pointer"
                    >
                      Details ▾
                    </button>
                  </div>
                </form>
              )}

              {/* Amazon-style Card Divider */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-stone-200" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-white px-2 text-stone-500 font-medium">
                    {role === 'student'
                      ? 'New customer to NBKRCN?'
                      : 'Station administration?'}
                  </span>
                </div>
              </div>

              {/* Amazon Secondary Button: Create Student Account */}
              {role === 'student' ? (
                <button
                  type="button"
                  onClick={() => navigate('/register')}
                  className="w-full py-2.5 px-3 text-xs font-semibold text-stone-800 bg-stone-50 hover:bg-stone-100 active:bg-stone-200 border border-stone-300 rounded-xl shadow-xs transition-colors cursor-pointer text-center"
                >
                  Create your NBKRCN Student account
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleBackToOptions}
                  className="w-full py-2.5 px-3 text-xs font-semibold text-stone-700 bg-stone-50 hover:bg-stone-100 active:bg-stone-200 border border-stone-300 rounded-xl shadow-xs transition-colors cursor-pointer text-center"
                >
                  Switch to Customer Option
                </button>
              )}
            </div>

            {/* Quick Demo Access Bar */}
            <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-center justify-between text-xs">
              <span className="text-stone-500 font-medium">
                Testing Demo Account:
              </span>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin(role)}
                className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 font-semibold rounded-md transition-colors cursor-pointer"
              >
                1-Click Demo Sign In ({role === 'student' ? 'Arjun' : 'Staff'})
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Details Modal for 'Keep me signed in' */}
      {showDetailsModal && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-2xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-xl max-w-sm w-full p-6 shadow-xl space-y-4 border border-stone-300">
            <h3 className="font-bold text-stone-900 text-base">
              "Keep Me Signed In" Checkbox
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Choosing "Keep me signed in" reduces the number of times you are
              asked to Sign-In on this device between class breaks.
            </p>
            <p className="text-xs text-stone-600 leading-relaxed">
              To keep your college food tokens secure, do not use this option
              if you are using a shared library or computer lab terminal.
            </p>
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setShowDetailsModal(false)}
                className="px-4 py-1.5 bg-[#FFD814] hover:bg-[#F7CA00] border border-[#FCD200] rounded-md text-xs font-medium text-stone-900 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Canteen Counter UPI QR Modal ("use this qr") */}
      {showQRModal && (
        <div className="fixed inset-0 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="relative max-w-md w-full bg-stone-900 rounded-3xl p-2 shadow-2xl border border-stone-700">
            <button
              onClick={() => setShowQRModal(false)}
              className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            <CanteenUPIQRCode />
          </div>
        </div>
      )}

      {/* Amazon-style Subtle Footer */}
      <footer className="w-full py-8 border-t border-stone-200 bg-white text-center text-xs text-stone-600 mt-10">
        <div className="max-w-md mx-auto space-y-3 px-4">
          <div className="flex items-center justify-center gap-6 text-[11px] text-[#007185]">
            <a href="#conditions" className="hover:text-[#C7511F] hover:underline">
              Conditions of Use
            </a>
            <a href="#privacy" className="hover:text-[#C7511F] hover:underline">
              Privacy Notice
            </a>
            <a href="#help" className="hover:text-[#C7511F] hover:underline">
              Canteen Help & FAQ
            </a>
            <button
              onClick={() => {
                setPageStep(1);
                navigate('/');
              }}
              className="hover:text-[#C7511F] hover:underline cursor-pointer"
            >
              Campus Portal
            </button>
          </div>

          <p className="text-[11px] text-stone-500">
            © 2026, NBKR Institute of Science & Technology, Inc. or its affiliates
          </p>
          <p className="text-[10px] text-stone-400">
            Vidyanagar, Kota, Tirupati District, Andhra Pradesh · FSSAI Food Safety
            Standards
          </p>
        </div>
      </footer>
    </div>
  );
};
