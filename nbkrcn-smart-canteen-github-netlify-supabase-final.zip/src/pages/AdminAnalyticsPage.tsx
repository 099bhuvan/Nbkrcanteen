import React, { useState, useMemo } from 'react';
import { useCanteen } from '../context/CanteenContext';
import {
  TrendingUp,
  Download,
  Calendar,
  DollarSign,
  ShoppingBag,
  Users,
  Award,
  Clock,
  ArrowUpRight
} from 'lucide-react';

interface AdminAnalyticsPageProps {
  navigate: (route: string) => void;
}

export const AdminAnalyticsPage: React.FC<AdminAnalyticsPageProps> = ({ navigate }) => {
  const { orders, menuItems } = useCanteen();
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month'>('today');

  // Filter orders based on range
  const validOrders = useMemo(() => {
    return orders.filter((o) => o.status !== 'cancelled' && o.status !== 'rejected');
  }, [orders]);

  // Aggregate metrics
  const totalRevenue = useMemo(() => {
    return validOrders.reduce((acc, o) => acc + o.total, 0);
  }, [validOrders]);

  const avgOrderValue = useMemo(() => {
    return validOrders.length > 0 ? Math.round(totalRevenue / validOrders.length) : 0;
  }, [validOrders, totalRevenue]);

  // Popular items tally
  const itemPerformance = useMemo(() => {
    const map = new Map<string, { name: string; count: number; revenue: number }>();

    validOrders.forEach((o) => {
      o.items.forEach((item) => {
        const existing = map.get(item.name) || { name: item.name, count: 0, revenue: 0 };
        existing.count += item.quantity;
        existing.revenue += item.price * item.quantity;
        map.set(item.name, existing);
      });
    });

    return Array.from(map.values()).sort((a, b) => b.count - a.count);
  }, [validOrders]);

  const topItem = itemPerformance[0] || { name: 'Crispy Masala Dosa', count: 18, revenue: 810 };

  // Hourly distribution for peak time analysis
  const hourlyData = [
    { hour: '08:30 AM', label: 'Breakfast', count: 24, percent: 45 },
    { hour: '10:30 AM', label: 'Short Break', count: 52, percent: 85 },
    { hour: '12:45 PM', label: 'Lunch Bell', count: 78, percent: 100 },
    { hour: '02:00 PM', label: 'Post-Lunch', count: 18, percent: 30 },
    { hour: '03:30 PM', label: 'Tea Break', count: 48, percent: 75 },
    { hour: '05:00 PM', label: 'Campus Close', count: 12, percent: 20 },
  ];

  // Category distribution
  const categoryStats = useMemo(() => {
    const cats: Record<string, number> = {
      Breakfast: 0,
      Meals: 0,
      Snacks: 0,
      Beverages: 0,
      Combos: 0,
    };

    validOrders.forEach((o) => {
      o.items.forEach((item) => {
        const found = menuItems.find((m) => m.name === item.name);
        const cat = found?.category || 'Snacks';
        cats[cat] = (cats[cat] || 0) + item.quantity;
      });
    });

    const totalItems = Object.values(cats).reduce((a, b) => a + b, 0) || 1;

    return Object.entries(cats).map(([name, count]) => ({
      name,
      count,
      percent: Math.round((count / totalItems) * 100),
    }));
  }, [validOrders, menuItems]);

  // Export to CSV function
  const handleExportCSV = () => {
    let csv = 'Order ID,Token,Student Name,Roll Number,Total (INR),Status,Pickup Time,Date\n';

    validOrders.forEach((o) => {
      csv += `"${o.id}","${o.tokenNumber}","${o.studentName}","${o.studentRoll}",${o.total},"${o.status}","${o.scheduledPickupTime}","${o.createdAt}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `NBKRCN_canteen_report_${dateRange}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-stone-50 py-6 px-4 sm:px-6 lg:px-8 space-y-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-stone-900 tracking-tight">
              Canteen Revenue & Operations Analytics
            </h1>
            <p className="text-xs text-stone-500 mt-0.5">
              Live operational metrics, rush hour patterns, and sales trends for NBKR administrators
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Date range picker */}
            <div className="flex items-center gap-1 p-1 bg-stone-200/70 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setDateRange('today')}
                className={`px-3 py-1.5 rounded-lg cursor-pointer ${
                  dateRange === 'today' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                }`}
              >
                Today
              </button>
              <button
                onClick={() => setDateRange('week')}
                className={`px-3 py-1.5 rounded-lg cursor-pointer ${
                  dateRange === 'week' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                }`}
              >
                This Week
              </button>
              <button
                onClick={() => setDateRange('month')}
                className={`px-3 py-1.5 rounded-lg cursor-pointer ${
                  dateRange === 'month' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                }`}
              >
                This Month
              </button>
            </div>

            {/* CSV Export Button */}
            <button
              onClick={handleExportCSV}
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* KPI Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
              <span>Total Orders Served</span>
              <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-stone-900 tabular-nums">
              {validOrders.length}
            </div>
            <p className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              <span>+18% from last week</span>
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
              <span>Total Gross Revenue</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-stone-900 tabular-nums">
              ₹{totalRevenue.toLocaleString()}
            </div>
            <p className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              <span>Campus peak hours active</span>
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
              <span>Average Order Value</span>
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-stone-900 tabular-nums">
              ₹{avgOrderValue}
            </div>
            <p className="text-[11px] text-stone-500">
              ~2.2 dishes per student order
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
              <span>Top Campus Dish</span>
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <div className="text-lg font-bold text-stone-900 truncate">
              {topItem.name}
            </div>
            <p className="text-[11px] text-orange-600 font-semibold tabular-nums">
              {topItem.count} servings ordered
            </p>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Peak Order Hours Bar Chart */}
          <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-stone-900 text-base">Peak Order Hours (Campus Rush Analysis)</h3>
                <p className="text-xs text-stone-500">Break schedules vs order volume distribution</p>
              </div>
              <span className="text-xs font-semibold text-orange-600 bg-orange-50 px-2.5 py-1 rounded-md">
                12:45 PM Lunch Peak
              </span>
            </div>

            {/* Custom SVG / Div Bar Chart */}
            <div className="pt-4 space-y-3">
              {hourlyData.map((d) => (
                <div key={d.hour} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-stone-700 w-20">{d.hour}</span>
                    <span className="text-stone-400 font-medium">{d.label}</span>
                    <span className="font-bold text-stone-900 tabular-nums">{d.count} orders</span>
                  </div>
                  <div className="h-4 w-full bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        d.percent === 100
                          ? 'bg-orange-600'
                          : d.percent >= 70
                          ? 'bg-amber-500'
                          : 'bg-stone-400'
                      }`}
                      style={{ width: `${d.percent}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Category Breakdown */}
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Category Sales Share</h3>
              <p className="text-xs text-stone-500">Demand split by food categories</p>
            </div>

            <div className="space-y-3 pt-2">
              {categoryStats.map((cat) => (
                <div key={cat.name} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-stone-800">{cat.name}</span>
                    <span className="font-bold text-stone-900 tabular-nums">{cat.percent}%</span>
                  </div>
                  <div className="h-2 w-full bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-orange-500 rounded-full"
                      style={{ width: `${Math.max(8, cat.percent)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Selling Items Table */}
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="p-5 border-b border-stone-100 flex items-center justify-between">
            <h3 className="font-bold text-stone-900 text-base">Top Performing Dishes</h3>
            <span className="text-xs text-stone-500">Sorted by frequency of order</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-500 uppercase tracking-wider font-semibold border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4">Rank</th>
                  <th className="py-3 px-4">Dish Name</th>
                  <th className="py-3 px-4">Servings Sold</th>
                  <th className="py-3 px-4">Total Revenue Generated</th>
                  <th className="py-3 px-4">Kitchen Velocity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {itemPerformance.slice(0, 7).map((item, index) => (
                  <tr key={item.name} className="hover:bg-stone-50/70">
                    <td className="py-3 px-4 font-bold text-stone-400 tabular-nums">
                      #{index + 1}
                    </td>
                    <td className="py-3 px-4 font-bold text-stone-900">
                      {item.name}
                    </td>
                    <td className="py-3 px-4 text-stone-700 font-semibold tabular-nums">
                      {item.count} orders
                    </td>
                    <td className="py-3 px-4 font-bold text-orange-600 tabular-nums">
                      ₹{item.revenue}
                    </td>
                    <td className="py-3 px-4 text-stone-500">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                        High Demand
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
