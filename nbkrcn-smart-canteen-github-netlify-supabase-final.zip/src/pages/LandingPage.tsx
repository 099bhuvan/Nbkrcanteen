import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { UserRole } from '../types';
import { ArrowRight, QrCode, Clock, Utensils, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface LandingPageProps {
  navigate: (route: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ navigate }) => {
  const { login, loginAsPreset, currentUser } = useCanteen();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [errorMsg, setErrorMsg] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('Please enter your college email address');
      return;
    }
    const success = login(email, selectedRole);
    if (success) {
      if (selectedRole === 'student') {
        navigate('/dashboard');
      } else {
        navigate('/staff/dashboard');
      }
    } else {
      setErrorMsg('Login failed. Please check your credentials.');
    }
  };

  const handleQuickDemo = (role: UserRole) => {
    loginAsPreset(role);
    if (role === 'student') {
      navigate('/dashboard');
    } else if (role === 'staff') {
      navigate('/staff/dashboard');
    } else {
      navigate('/admin/analytics');
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col">
      {/* Top Banner Notice */}
      <div className="bg-stone-900 text-stone-200 px-4 py-2 text-xs text-center border-b border-stone-800">
        <span className="font-medium text-amber-400">Campus Dining Portal:</span> NBKR Institute of Science & Technology Canteen
      </div>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 sm:py-12 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Hero Copy & Value Props */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100/80 border border-orange-200 rounded-full text-xs font-semibold text-orange-800">
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
              <span>Smart Canteen 2.0 Live On Campus</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight leading-tight">
              Skip the Queue. <br />
              <span className="text-orange-600">Order Smart.</span> Collect Fast.
            </h1>

            <p className="text-stone-600 text-base sm:text-lg max-w-2xl leading-relaxed">
              NBKRCN eliminates lunch break chaos. Browse real-time food availability, place orders straight from your classroom, track kitchen prep status, and collect food using your digital token QR code.
            </p>

            {/* Feature Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs hover:border-orange-200 transition-colors">
                <div className="w-9 h-9 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center mb-3">
                  <Utensils className="w-5 h-5" />
                </div>
                <h3 className="font-semibold text-stone-900 text-sm">Live Menu & Stock</h3>
                <p className="text-stone-500 text-xs mt-1">
                  Instant stock counters so you never walk in on sold-out dishes.
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs hover:border-orange-200 transition-colors">
                <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
                  <Clock className="w-5 h-5" />
                </div>
                <h3 className="font-semibold text-stone-900 text-sm">Break-Time Ordering</h3>
                <p className="text-stone-500 text-xs mt-1">
                  Pre-order 15 to 60 mins ahead so hot food is ready as the bell rings.
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs hover:border-orange-200 transition-colors">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                  <QrCode className="w-5 h-5" />
                </div>
                <h3 className="font-semibold text-stone-900 text-sm">Digital Token QR</h3>
                <p className="text-stone-500 text-xs mt-1">
                  Zero token paper waste. Flash your digital token code at the counter.
                </p>
              </div>
            </div>

            {/* If user already authenticated */}
            {currentUser && (
              <div className="p-4 bg-orange-50 border border-orange-200 rounded-xl flex items-center justify-between">
                <div>
                  <p className="text-xs text-orange-800 font-semibold">Currently logged in as:</p>
                  <p className="text-sm font-bold text-stone-900">{currentUser.name} ({currentUser.role})</p>
                </div>
                <button
                  onClick={() => navigate(currentUser.role === 'student' ? '/dashboard' : '/staff/dashboard')}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <span>Go to App</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Right Column: College Sign-In & Instant Demo Tester */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-stone-900 tracking-tight">College Portal Login</h2>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Sign in with your official NBKR student ID or staff credentials
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigate('/login')}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-[#FFD814] hover:bg-[#F7CA00] border border-[#FCD200] rounded-md text-stone-900 shadow-xs cursor-pointer transition-colors"
                  title="Switch to Amazon-style Login Page"
                >
                  Amazon Style ↗
                </button>
              </div>

              {/* Role selection toggle */}
              <div className="p-1 bg-stone-100 rounded-xl grid grid-cols-3 gap-1 text-xs font-medium text-stone-600">
                <button
                  type="button"
                  onClick={() => setSelectedRole('student')}
                  className={`py-2 text-center rounded-lg transition-all cursor-pointer ${
                    selectedRole === 'student' ? 'bg-white text-orange-600 font-bold shadow-xs' : 'hover:text-stone-900'
                  }`}
                >
                  Student
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRole('staff')}
                  className={`py-2 text-center rounded-lg transition-all cursor-pointer ${
                    selectedRole === 'staff' ? 'bg-white text-orange-600 font-bold shadow-xs' : 'hover:text-stone-900'
                  }`}
                >
                  Canteen Staff
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRole('admin')}
                  className={`py-2 text-center rounded-lg transition-all cursor-pointer ${
                    selectedRole === 'admin' ? 'bg-white text-orange-600 font-bold shadow-xs' : 'hover:text-stone-900'
                  }`}
                >
                  Admin
                </button>
              </div>

              {/* Login Form */}
              <form onSubmit={handleLogin} className="space-y-4">
                {errorMsg && (
                  <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200">
                    {errorMsg}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    {selectedRole === 'student' ? 'College Email / Roll ID' : 'Staff Email Address'}
                  </label>
                  <input
                    type="text"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={
                      selectedRole === 'student'
                        ? 'arjun.sharma@nbkrcn.edu.in'
                        : selectedRole === 'staff'
                        ? 'staff@nbkrcn.edu.in'
                        : 'admin@nbkrcn.edu.in'
                    }
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-colors"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-stone-700">Password</label>
                    <span className="text-[11px] text-stone-400">Default: password123</span>
                  </div>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Sign In as {selectedRole.toUpperCase()}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* 1-Click Instant Demo Launchers */}
              <div className="pt-2 border-t border-stone-100">
                <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mb-2 text-center">
                  Instant 1-Click Quick Demo Login
                </p>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickDemo('student')}
                    className="p-2 border border-orange-200 bg-orange-50/60 hover:bg-orange-100 rounded-lg text-center transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-orange-900">Student</p>
                    <p className="text-[10px] text-stone-500">Arjun Sharma</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickDemo('staff')}
                    className="p-2 border border-stone-200 bg-stone-50 hover:bg-stone-100 rounded-lg text-center transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Kitchen Staff</p>
                    <p className="text-[10px] text-stone-500">Counter 1</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickDemo('admin')}
                    className="p-2 border border-stone-200 bg-stone-50 hover:bg-stone-100 rounded-lg text-center transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-stone-900">Admin</p>
                    <p className="text-[10px] text-stone-500">Dr. Prasad</p>
                  </button>
                </div>
              </div>

              {/* Register link */}
              <div className="text-center text-xs text-stone-500 pt-2">
                New student at NBKR?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/register')}
                  className="font-bold text-orange-600 hover:text-orange-700 underline cursor-pointer"
                >
                  Create Student Account
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* College footer */}
      <footer className="border-t border-stone-200 bg-white py-6 text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© 2026 NBKR Institute of Science & Technology – Smart Canteen System</p>
          <div className="flex items-center gap-4 text-stone-400">
            <span>Vidyanagar, Kota, Tirupati Dist.</span>
            <span>·</span>
            <span>FSSAI Certified Kitchen</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
