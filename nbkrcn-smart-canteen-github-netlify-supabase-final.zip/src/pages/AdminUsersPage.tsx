import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { UserProfile, UserRole } from '../types';
import {
  Users,
  UserPlus,
  Search,
  ShieldCheck,
  GraduationCap,
  CheckCircle2,
  XCircle,
  MoreVertical,
  Plus
} from 'lucide-react';

interface AdminUsersPageProps {
  navigate: (route: string) => void;
}

export const AdminUsersPage: React.FC<AdminUsersPageProps> = ({ navigate }) => {
  const { users, orders, addStaffAccount, toggleUserStatus } = useCanteen();

  const [activeTab, setActiveTab] = useState<'students' | 'staff'>('students');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddStaffOpen, setIsAddStaffOpen] = useState(false);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<'staff' | 'admin'>('staff');

  const studentsList = users.filter((u) => u.role === 'student');
  const staffList = users.filter((u) => u.role === 'staff' || u.role === 'admin');

  const filteredUsers = (activeTab === 'students' ? studentsList : staffList).filter((u) => {
    const q = searchQuery.toLowerCase();
    const matchName = u.name.toLowerCase().includes(q);
    const matchEmail = u.email.toLowerCase().includes(q);
    const matchRoll = u.rollNumber ? u.rollNumber.toLowerCase().includes(q) : false;
    return matchName || matchEmail || matchRoll;
  });

  const getStudentOrderCount = (studentId: string) => {
    return orders.filter((o) => o.studentId === studentId).length;
  };

  const handleAddStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName.trim() || !newStaffEmail.trim()) return;

    addStaffAccount(newStaffName, newStaffEmail, newStaffRole);
    setNewStaffName('');
    setNewStaffEmail('');
    setIsAddStaffOpen(false);
  };

  return (
    <div className="min-h-screen bg-stone-50 py-6 px-4 sm:px-6 lg:px-8 space-y-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-stone-900 tracking-tight">
              User & Staff Account Directory
            </h1>
            <p className="text-xs text-stone-500 mt-0.5">
              Manage student portal registrations and canteen operational staff permissions
            </p>
          </div>

          {activeTab === 'staff' && (
            <button
              onClick={() => setIsAddStaffOpen(true)}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Staff Account</span>
            </button>
          )}
        </div>

        {/* Tab Controls & Search */}
        <div className="bg-white rounded-2xl border border-stone-200 p-4 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-xl text-xs font-semibold w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('students')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
                activeTab === 'students'
                  ? 'bg-white text-stone-900 shadow-xs font-bold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-orange-600" />
              <span>Registered Students ({studentsList.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('staff')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
                activeTab === 'staff'
                  ? 'bg-white text-stone-900 shadow-xs font-bold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Staff & Admins ({staffList.length})</span>
            </button>
          </div>

          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, email, or roll..."
              className="w-full pl-10 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
            />
          </div>
        </div>

        {/* User Table */}
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="py-3 px-4">User</th>
                  {activeTab === 'students' && <th className="py-3 px-4">Roll Number</th>}
                  {activeTab === 'students' && <th className="py-3 px-4">Department & Year</th>}
                  {activeTab === 'students' && <th className="py-3 px-4">Total Orders</th>}
                  {activeTab === 'staff' && <th className="py-3 px-4">Assigned Role</th>}
                  <th className="py-3 px-4">Registered Date</th>
                  <th className="py-3 px-4">Account Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-stone-100">
                {filteredUsers.map((user) => {
                  const isActive = user.status !== 'inactive';

                  return (
                    <tr key={user.id} className="hover:bg-stone-50/70">
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-bold text-stone-900 text-sm">{user.name}</p>
                          <p className="text-[11px] text-stone-400">{user.email}</p>
                        </div>
                      </td>

                      {activeTab === 'students' && (
                        <td className="py-3 px-4 font-token font-bold text-stone-800">
                          {user.rollNumber || '—'}
                        </td>
                      )}

                      {activeTab === 'students' && (
                        <td className="py-3 px-4 text-stone-600">
                          <span>{user.department || 'General'}</span>
                          <span className="text-stone-400 block text-[11px]">{user.year || '3rd Year'}</span>
                        </td>
                      )}

                      {activeTab === 'students' && (
                        <td className="py-3 px-4 font-bold text-stone-900 tabular-nums">
                          {getStudentOrderCount(user.id)} orders
                        </td>
                      )}

                      {activeTab === 'staff' && (
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] font-bold uppercase ${
                              user.role === 'admin'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {user.role}
                          </span>
                        </td>
                      )}

                      <td className="py-3 px-4 text-stone-500">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                            isActive
                              ? 'bg-emerald-50 text-emerald-800'
                              : 'bg-stone-100 text-stone-500'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-500' : 'bg-stone-400'}`} />
                          {isActive ? 'Active' : 'Suspended'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => toggleUserStatus(user.id)}
                          className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer transition-colors ${
                            isActive
                              ? 'text-red-600 hover:bg-red-50'
                              : 'text-emerald-600 hover:bg-emerald-50'
                          }`}
                        >
                          {isActive ? 'Deactivate' : 'Reactivate'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Staff Account Modal */}
      {isAddStaffOpen && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4">
            <h3 className="font-bold text-stone-900 text-lg">Add Canteen Staff Member</h3>
            <p className="text-xs text-stone-500">
              Create an account for kitchen operators or supervisors with order queue permissions.
            </p>

            <form onSubmit={handleAddStaffSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Staff Member Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Naidu"
                  value={newStaffName}
                  onChange={(e) => setNewStaffName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="ramesh.canteen@nbkrcn.edu.in"
                  value={newStaffEmail}
                  onChange={(e) => setNewStaffEmail(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Role Permission
                </label>
                <select
                  value={newStaffRole}
                  onChange={(e) => setNewStaffRole(e.target.value as 'staff' | 'admin')}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg bg-white"
                >
                  <option value="staff">Canteen Staff (Order Queue & Menu)</option>
                  <option value="admin">Administrator (Full Access & Analytics)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddStaffOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-lg shadow-xs cursor-pointer"
                >
                  Create Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
