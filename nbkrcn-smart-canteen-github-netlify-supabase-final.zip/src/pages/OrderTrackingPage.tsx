import React, { useState, useEffect } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { QRCodeSVG } from 'qrcode.react';
import confetti from 'canvas-confetti';
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Bell,
  XCircle,
  ChefHat,
  ArrowRight,
  PackageCheck
} from 'lucide-react';
import { requestNotificationPermission } from '../utils/notifications';

interface OrderTrackingPageProps {
  navigate: (route: string) => void;
}

const STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'Received at canteen system' },
  { key: 'accepted', label: 'Accepted', desc: 'Queued in kitchen queue' },
  { key: 'preparing', label: 'Preparing', desc: 'Cooking fresh on the stove' },
  { key: 'ready', label: 'Ready for Pickup', desc: 'At counter for collection' },
  { key: 'collected', label: 'Collected', desc: 'Token redeemed & served' },
];

export const OrderTrackingPage: React.FC<OrderTrackingPageProps> = ({ navigate }) => {
  const { orders, currentUser, cancelOrder } = useCanteen();

  // Find most recent active or last order for the student
  const studentOrders = orders.filter((o) => o.studentId === currentUser?.id);
  const activeOrder =
    studentOrders.find(
      (o) =>
        o.status === 'placed' ||
        o.status === 'accepted' ||
        o.status === 'preparing' ||
        o.status === 'ready'
    ) || studentOrders[0];

  const [hasCelebrated, setHasCelebrated] = useState(false);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('Change of schedule / class started');
  const [remainingTime, setRemainingTime] = useState<string>('');

  // Fire confetti celebration when status moves to "ready"
  useEffect(() => {
    if (activeOrder?.status === 'ready' && !hasCelebrated) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#F97316', '#FBBF24', '#22C55E', '#3B82F6'],
      });
      setHasCelebrated(true);
    }
  }, [activeOrder?.status, hasCelebrated]);

  // Live ETA countdown
  useEffect(() => {
    if (!activeOrder) return;

    const calcTime = () => {
      const target = new Date(activeOrder.estimatedReadyAt).getTime();
      const diff = Math.max(0, Math.floor((target - Date.now()) / 1000));

      if (diff <= 0 || activeOrder.status === 'ready' || activeOrder.status === 'collected') {
        setRemainingTime('Ready for pickup');
      } else {
        const m = Math.floor(diff / 60);
        const s = diff % 60;
        setRemainingTime(`${m}m ${s < 10 ? '0' : ''}${s}s`);
      }
    };

    calcTime();
    const interval = setInterval(calcTime, 1000);
    return () => clearInterval(interval);
  }, [activeOrder]);

  if (!activeOrder) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white p-8 rounded-2xl border border-stone-200 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-full bg-stone-100 text-stone-500 flex items-center justify-center mx-auto">
            <Clock className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-stone-900">No Active Order in Tracking</h2>
          <p className="text-xs text-stone-500">
            You don't have any ongoing canteen orders right now. Order food from the menu to track live preparation!
          </p>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
          >
            Explore Menu
          </button>
        </div>
      </div>
    );
  }

  // Calculate current step index
  const getStepIndex = (status: string) => {
    switch (status) {
      case 'placed':
        return 0;
      case 'accepted':
        return 1;
      case 'preparing':
        return 2;
      case 'ready':
        return 3;
      case 'collected':
        return 4;
      default:
        return -1;
    }
  };

  const currentStepIdx = getStepIndex(activeOrder.status);
  const isCancellable = activeOrder.status === 'placed' || activeOrder.status === 'accepted';

  const handleConfirmCancel = () => {
    cancelOrder(activeOrder.id, cancelReason);
    setCancelModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-stone-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Page Heading */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-stone-900 tracking-tight">Order Live Tracker</h1>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Real-time sync with NBKR Canteen kitchen queue
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={requestNotificationPermission}
              className="px-3 py-1.5 rounded-lg border border-stone-200 bg-white text-stone-700 hover:bg-stone-50 text-xs font-medium flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Bell className="w-3.5 h-3.5 text-stone-500" />
              <span>Allow Notifications</span>
            </button>
            <button
              onClick={() => navigate('/orders/history')}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-orange-600 hover:text-orange-700 cursor-pointer"
            >
              View History
            </button>
          </div>
        </div>

        {/* Status Callout Banner */}
        {activeOrder.status === 'ready' && (
          <div className="p-4 bg-emerald-50 border-2 border-emerald-500 rounded-2xl flex items-center gap-3 text-emerald-900 shadow-sm animate-in zoom-in-95">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <PackageCheck className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-sm">Your Food is Ready at Counter!</h3>
              <p className="text-xs text-emerald-700">
                Please proceed to Canteen Counter with token <strong>{activeOrder.tokenNumber}</strong> to collect your meal.
              </p>
            </div>
          </div>
        )}

        {activeOrder.status === 'cancelled' && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3 text-red-900">
            <XCircle className="w-6 h-6 text-red-600 shrink-0" />
            <div>
              <h3 className="font-bold text-sm">Order Cancelled</h3>
              <p className="text-xs text-red-700">
                Reason: {activeOrder.cancellationReason || 'Cancelled by user'}
              </p>
            </div>
          </div>
        )}

        {/* Main Tracker Card */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-8">
          {/* Header row: Token & ETA */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-100">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-white rounded-xl border border-stone-200 shadow-xs">
                <QRCodeSVG
                  value={`NBKRCN_TOKEN:${activeOrder.tokenNumber}`}
                  size={64}
                  level="M"
                />
              </div>
              <div>
                <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block">
                  Collection Token
                </span>
                <span className="font-token font-bold text-3xl sm:text-4xl text-orange-600 tracking-wider">
                  {activeOrder.tokenNumber}
                </span>
                <p className="text-xs text-stone-500">
                  Scheduled for: <strong className="text-stone-800">{activeOrder.scheduledPickupTime}</strong>
                </p>
              </div>
            </div>

            <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200 text-right sm:min-w-[160px]">
              <span className="text-[11px] font-semibold text-stone-400 block">Est. Preparation ETA</span>
              <span className="font-token font-bold text-xl text-stone-900 tabular-nums">
                {remainingTime}
              </span>
              <span className="text-[10px] text-stone-400 block mt-0.5">
                ~{activeOrder.estimatedReadyMinutes} mins total kitchen time
              </span>
            </div>
          </div>

          {/* Stepper Progress Bar */}
          {activeOrder.status !== 'cancelled' && activeOrder.status !== 'rejected' && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-stone-900">Kitchen Preparation Status</h3>
              <div className="relative">
                {/* Connecting Line */}
                <div className="absolute top-4 left-4 right-4 h-0.5 bg-stone-200 -z-0" />
                <div
                  className="absolute top-4 left-4 h-0.5 bg-orange-600 transition-all duration-500 -z-0"
                  style={{
                    width: `${Math.min(100, Math.max(0, (currentStepIdx / (STEPS.length - 1)) * 100))}%`,
                  }}
                />

                {/* Steps */}
                <div className="grid grid-cols-5 gap-2 relative z-10">
                  {STEPS.map((step, idx) => {
                    const isCompleted = idx < currentStepIdx;
                    const isCurrent = idx === currentStepIdx;

                    return (
                      <div key={step.key} className="flex flex-col items-center text-center">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-xs ${
                            isCompleted
                              ? 'bg-orange-600 text-white'
                              : isCurrent
                              ? 'bg-orange-500 text-white ring-4 ring-orange-100 animate-pulse'
                              : 'bg-white border-2 border-stone-300 text-stone-400'
                          }`}
                        >
                          {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                        </div>
                        <p
                          className={`text-xs font-semibold mt-2 ${
                            isCurrent
                              ? 'text-orange-600 font-bold'
                              : isCompleted
                              ? 'text-stone-900'
                              : 'text-stone-400'
                          }`}
                        >
                          {step.label}
                        </p>
                        <p className="text-[10px] text-stone-400 hidden sm:block mt-0.5 leading-tight">
                          {step.desc}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Ordered items breakdown */}
          <div className="pt-4 border-t border-stone-100 space-y-3">
            <h4 className="font-bold text-xs uppercase tracking-wider text-stone-500">Order Summary</h4>
            <div className="divide-y divide-stone-100 bg-stone-50/50 rounded-xl p-3 border border-stone-200">
              {activeOrder.items.map((item, idx) => (
                <div key={idx} className="py-2 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-stone-900">{item.name}</span>
                    <span className="text-stone-400 ml-2">× {item.quantity}</span>
                    {item.specialInstructions && (
                      <p className="text-[11px] text-orange-600 italic">"{item.specialInstructions}"</p>
                    )}
                  </div>
                  <span className="font-bold text-stone-900 tabular-nums">
                    ₹{item.price * item.quantity}
                  </span>
                </div>
              ))}

              <div className="pt-2 flex items-center justify-between text-xs font-bold text-stone-900">
                <span>Total Amount</span>
                <span className="text-sm text-orange-600 tabular-nums">₹{activeOrder.total}</span>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs border-t border-stone-200">
                <span className="text-stone-500 font-medium">Payment:</span>
                {activeOrder.paymentMethod === 'UPI' ? (
                  <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>UPI Paid (7702479214@fam - kull bhuvan)</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded text-[11px]">
                    <span>Pay ₹{activeOrder.total} Cash at Counter</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Cancel Order Section (Conditioned on status) */}
          {isCancellable && (
            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs text-stone-400">
                Need to cancel? You can cancel before cooking begins.
              </span>
              <button
                type="button"
                onClick={() => setCancelModalOpen(true)}
                className="px-3.5 py-1.5 border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Cancel Order
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Cancel Order Modal */}
      {cancelModalOpen && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Cancel Canteen Order?</h3>
              <p className="text-xs text-stone-500 mt-1">
                Token <strong>{activeOrder.tokenNumber}</strong> will be released.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Reason for Cancellation
              </label>
              <select
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full text-xs p-2.5 rounded-lg border border-stone-300 bg-white"
              >
                <option value="Change of schedule / class started">Change of schedule / class started</option>
                <option value="Ordered by mistake">Ordered by mistake</option>
                <option value="Break ended early">Break ended early</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCancelModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
              >
                Keep Order
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
