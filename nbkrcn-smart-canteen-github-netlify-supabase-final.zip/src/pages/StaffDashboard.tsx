import React, { useState, useMemo } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { Order, OrderStatus } from '../types';
import { playOrderChime } from '../utils/audio';
import { CanteenUPIQRCode } from '../components/CanteenUPIQRCode';
import {
  Volume2,
  VolumeX,
  Search,
  CheckCircle,
  Clock,
  ChefHat,
  PackageCheck,
  AlertCircle,
  XCircle,
  Filter,
  Check,
  Ban,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  QrCode,
  X
} from 'lucide-react';

interface StaffDashboardProps {
  navigate: (route: string) => void;
}

export const StaffDashboard: React.FC<StaffDashboardProps> = ({ navigate }) => {
  const { orders, updateOrderStatus, chimeEnabled, toggleChime, currentUser } = useCanteen();

  const [activeTab, setActiveTab] = useState<'queue' | 'ready' | 'collected' | 'all'>('queue');
  const [tokenSearch, setTokenSearch] = useState('');
  const [rejectModalOrder, setRejectModalOrder] = useState<Order | null>(null);
  const [rejectReason, setRejectReason] = useState('Item out of stock in kitchen');
  const [showCounterQRModal, setShowCounterQRModal] = useState(false);

  // Stats calculation
  const stats = useMemo(() => {
    const today = orders;
    const pending = today.filter((o) => o.status === 'placed');
    const accepted = today.filter((o) => o.status === 'accepted');
    const preparing = today.filter((o) => o.status === 'preparing');
    const ready = today.filter((o) => o.status === 'ready');
    const collected = today.filter((o) => o.status === 'collected');
    const revenue = today.filter((o) => o.status !== 'cancelled' && o.status !== 'rejected').reduce((sum, o) => sum + o.total, 0);

    return {
      total: today.length,
      pending: pending.length,
      preparing: accepted.length + preparing.length,
      ready: ready.length,
      collected: collected.length,
      revenue,
    };
  }, [orders]);

  // Filtered orders
  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      // Tab filter
      if (activeTab === 'queue') {
        if (o.status !== 'placed' && o.status !== 'accepted' && o.status !== 'preparing') return false;
      } else if (activeTab === 'ready') {
        if (o.status !== 'ready') return false;
      } else if (activeTab === 'collected') {
        if (o.status !== 'collected') return false;
      }

      // Search token or student name
      if (tokenSearch.trim()) {
        const q = tokenSearch.toLowerCase().replace('#', '');
        const matchToken = o.tokenNumber.toLowerCase().includes(q);
        const matchStudent = o.studentName.toLowerCase().includes(q) || o.studentRoll.toLowerCase().includes(q);
        if (!matchToken && !matchStudent) return false;
      }

      return true;
    });
  }, [orders, activeTab, tokenSearch]);

  const handleTestChime = () => {
    playOrderChime();
  };

  const handleConfirmReject = () => {
    if (rejectModalOrder) {
      updateOrderStatus(rejectModalOrder.id, 'rejected', rejectReason);
      setRejectModalOrder(null);
    }
  };

  const getElapsedTime = (createdAt: string) => {
    const diffMin = Math.max(0, Math.floor((Date.now() - new Date(createdAt).getTime()) / 60000));
    if (diffMin === 0) return 'Just now';
    return `${diffMin}m ago`;
  };

  return (
    <div className="min-h-screen bg-stone-50 py-6 px-4 sm:px-6 lg:px-8 space-y-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Header & Chime Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight">
                Live Kitchen Order Queue
              </h1>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Service Station Counter 1 · Orders sync live across student devices
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleTestChime}
              className="px-3 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5 text-stone-500" />
              <span>Test Bell</span>
            </button>

            <button
              onClick={toggleChime}
              className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors ${
                chimeEnabled
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-stone-100 text-stone-500 border-stone-200'
              }`}
            >
              {chimeEnabled ? <Volume2 className="w-4 h-4 text-amber-600" /> : <VolumeX className="w-4 h-4" />}
              <span>{chimeEnabled ? 'Chime Active' : 'Chime Muted'}</span>
            </button>

            <button
              onClick={() => setShowCounterQRModal(true)}
              className="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-lg shadow-xs cursor-pointer flex items-center gap-1.5 transition-colors"
            >
              <QrCode className="w-4 h-4" />
              <span>Counter UPI QR</span>
            </button>

            <button
              onClick={() => navigate('/staff/menu')}
              className="px-3.5 py-1.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-lg shadow-xs cursor-pointer"
            >
              Manage Menu & Stock →
            </button>
          </div>
        </div>

        {/* Summary Stats Strip (KPIs) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-stone-200 shadow-xs">
            <span className="text-[11px] font-semibold text-stone-400 block">Total Orders</span>
            <span className="font-bold text-xl text-stone-900 tabular-nums">{stats.total}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-amber-200 bg-amber-50/20 shadow-xs">
            <span className="text-[11px] font-semibold text-amber-700 block">Incoming (Placed)</span>
            <span className="font-bold text-xl text-amber-600 tabular-nums">{stats.pending}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-blue-200 bg-blue-50/20 shadow-xs">
            <span className="text-[11px] font-semibold text-blue-700 block">Cooking / Accepted</span>
            <span className="font-bold text-xl text-blue-600 tabular-nums">{stats.preparing}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-emerald-300 bg-emerald-50/30 shadow-xs">
            <span className="text-[11px] font-semibold text-emerald-800 block">Ready at Counter</span>
            <span className="font-bold text-xl text-emerald-600 tabular-nums">{stats.ready}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-stone-200 shadow-xs">
            <span className="text-[11px] font-semibold text-stone-500 block">Collected Today</span>
            <span className="font-bold text-xl text-stone-700 tabular-nums">{stats.collected}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-stone-200 shadow-xs">
            <span className="text-[11px] font-semibold text-stone-500 block">Today's Revenue</span>
            <span className="font-bold text-xl text-orange-600 tabular-nums">₹{stats.revenue}</span>
          </div>
        </div>

        {/* Filter Tabs & Token Search Bar */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          {/* Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-stone-200/60 rounded-xl w-full sm:w-auto text-xs font-semibold">
            <button
              onClick={() => setActiveTab('queue')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'queue' ? 'bg-white text-stone-900 shadow-xs font-bold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <span>Kitchen Queue</span>
              {stats.pending + stats.preparing > 0 && (
                <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px]">
                  {stats.pending + stats.preparing}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('ready')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'ready' ? 'bg-white text-emerald-800 shadow-xs font-bold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <span>Ready at Counter</span>
              {stats.ready > 0 && (
                <span className="px-1.5 py-0.2 bg-emerald-600 text-white rounded-full text-[10px]">
                  {stats.ready}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('collected')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'collected' ? 'bg-white text-stone-900 shadow-xs font-bold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Collected
            </button>

            <button
              onClick={() => setActiveTab('all')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'all' ? 'bg-white text-stone-900 shadow-xs font-bold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              All Orders
            </button>
          </div>

          {/* Quick Counter Token Search */}
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={tokenSearch}
              onChange={(e) => setTokenSearch(e.target.value)}
              placeholder="Search Token (e.g. 4829) or Student..."
              className="w-full pl-10 pr-3 py-2 bg-white text-xs border border-stone-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
            />
            {tokenSearch && (
              <button
                onClick={() => setTokenSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Orders Grid */}
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-stone-900 text-base">No Orders in this View</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              The kitchen queue is clear! When students place orders via NBKRCN, they will appear here with an audio chime.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {filteredOrders.map((order) => {
              const isPlaced = order.status === 'placed';
              const isAccepted = order.status === 'accepted';
              const isPreparing = order.status === 'preparing';
              const isReady = order.status === 'ready';
              const isCollected = order.status === 'collected';
              const isRejected = order.status === 'rejected';

              return (
                <div
                  key={order.id}
                  className={`bg-white rounded-2xl border transition-all duration-200 p-5 shadow-xs flex flex-col justify-between space-y-4 ${
                    isPlaced
                      ? 'border-amber-400 ring-2 ring-amber-100 bg-amber-50/20'
                      : isReady
                      ? 'border-emerald-400 ring-2 ring-emerald-100'
                      : 'border-stone-200'
                  }`}
                >
                  {/* Top: Token, Time, Status */}
                  <div className="space-y-2 border-b border-stone-100 pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-token font-bold text-2xl text-stone-900 tracking-wider">
                          {order.tokenNumber}
                        </span>
                        {isPlaced && (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-bold uppercase animate-pulse">
                            NEW
                          </span>
                        )}
                      </div>

                      <span
                        className={`text-xs font-semibold px-2.5 py-0.5 rounded-full capitalize ${
                          isReady
                            ? 'bg-emerald-100 text-emerald-800'
                            : isPreparing
                            ? 'bg-blue-100 text-blue-800'
                            : isAccepted
                            ? 'bg-purple-100 text-purple-800'
                            : isPlaced
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-stone-100 text-stone-700'
                        }`}
                      >
                        {order.status}
                      </span>
                    </div>

                    {/* Student details */}
                    <div className="flex items-center justify-between text-xs text-stone-500">
                      <div>
                        <span className="font-semibold text-stone-800">{order.studentName}</span>
                        <span className="ml-1 text-[11px] text-stone-400">({order.studentRoll})</span>
                      </div>
                      <span className="text-[11px] font-medium text-stone-400">
                        {getElapsedTime(order.createdAt)}
                      </span>
                    </div>

                    <div className="text-[11px] text-orange-700 bg-orange-50 px-2 py-1 rounded-md font-medium flex items-center justify-between">
                      <span>Pickup: {order.scheduledPickupTime}</span>
                      <span>ETA: ~{order.estimatedReadyMinutes}m</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1">
                      <span className="text-stone-400 font-medium">Payment:</span>
                      {order.paymentMethod === 'UPI' ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          <CheckCircle className="w-3 h-3 text-emerald-600" />
                          <span>UPI Paid (kull bhuvan)</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                          <span>Collect Cash ₹{order.total}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Middle: Items List */}
                  <div className="space-y-2 flex-1">
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-stone-400">
                      Ordered Items ({order.items.length})
                    </div>
                    <div className="space-y-1.5 divide-y divide-stone-50">
                      {order.items.map((item, i) => (
                        <div key={i} className="pt-1 text-xs">
                          <div className="flex items-center justify-between font-semibold text-stone-800">
                            <span>
                              {item.name} <span className="text-orange-600 font-bold">× {item.quantity}</span>
                            </span>
                            <span className="tabular-nums font-normal text-stone-500">
                              ₹{item.price * item.quantity}
                            </span>
                          </div>
                          {item.specialInstructions && (
                            <p className="text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded mt-0.5 inline-block">
                              Chef Note: "{item.specialInstructions}"
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bottom: Total & Kitchen Status Action Buttons */}
                  <div className="pt-3 border-t border-stone-100 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-stone-400">Total Bill</span>
                      <span className="font-bold text-base text-stone-900 tabular-nums">
                        ₹{order.total}
                      </span>
                    </div>

                    {/* Action buttons based on current state */}
                    <div className="space-y-2">
                      {isPlaced && (
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => updateOrderStatus(order.id, 'accepted')}
                            className="py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Accept</span>
                          </button>
                          <button
                            onClick={() => setRejectModalOrder(order)}
                            className="py-2 px-3 bg-stone-100 hover:bg-red-50 text-red-700 border border-stone-200 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Ban className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      )}

                      {isAccepted && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'preparing')}
                          className="w-full py-2.5 px-3 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <ChefHat className="w-4 h-4" />
                          <span>Mark as Preparing</span>
                        </button>
                      )}

                      {isPreparing && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'ready')}
                          className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <PackageCheck className="w-4 h-4" />
                          <span>Mark as Ready for Pickup</span>
                        </button>
                      )}

                      {isReady && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'collected')}
                          className="w-full py-2.5 px-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <CheckCircle className="w-4 h-4 text-emerald-400" />
                          <span>Verify Token & Mark Collected</span>
                        </button>
                      )}

                      {isCollected && (
                        <div className="py-2 text-center text-xs font-semibold text-stone-500 bg-stone-100 rounded-lg">
                          ✓ Completed & Collected
                        </div>
                      )}

                      {isRejected && (
                        <div className="py-2 text-center text-xs font-semibold text-red-600 bg-red-50 rounded-lg">
                          ✕ Rejected: {order.rejectionReason}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Reject Order Modal */}
      {rejectModalOrder && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Reject Order {rejectModalOrder.tokenNumber}?</h3>
              <p className="text-xs text-stone-500 mt-1">
                Student {rejectModalOrder.studentName} will be notified immediately.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Reason for Rejection
              </label>
              <select
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full text-xs p-2.5 rounded-lg border border-stone-300 bg-white"
              >
                <option value="Item out of stock in kitchen">Item out of stock in kitchen</option>
                <option value="Kitchen overloaded / high rush">Kitchen overloaded / high rush</option>
                <option value="Closing time reached">Closing time reached</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRejectModalOrder(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Counter UPI Payment QR Modal */}
      {showCounterQRModal && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-stone-950 rounded-3xl max-w-sm w-full p-4 relative shadow-2xl border border-stone-800">
            <button
              onClick={() => setShowCounterQRModal(false)}
              className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            <CanteenUPIQRCode className="border-0 shadow-none p-4" />
            <div className="text-center pt-2 pb-1">
              <p className="text-[11px] text-stone-400">
                Counter 1 Live Billing Screen · Students scan to pay
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
