import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { User, Shield, Phone, Mail, GraduationCap, Building2, Save, LogOut, CheckCircle2 } from 'lucide-react';

interface StudentProfilePageProps {
  navigate: (route: string) => void;
}

export const StudentProfilePage: React.FC<StudentProfilePageProps> = ({ navigate }) => {
  const { currentUser, updateProfile, logout } = useCanteen();

  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [year, setYear] = useState(currentUser?.year || '3rd Year');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [logoutModal, setLogoutModal] = useState(false);

  // Password fields
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [passMsg, setPassMsg] = useState('');

  if (!currentUser) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4">
        <p className="text-stone-500 text-sm">Please sign in to view your profile.</p>
        <button
          onClick={() => navigate('/')}
          className="mt-4 px-4 py-2 bg-orange-600 text-white rounded-lg text-xs font-semibold"
        >
          Go to Sign In
        </button>
      </div>
    );
  }

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      phone,
      year,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPass || !newPass) {
      setPassMsg('Please enter both current and new password.');
      return;
    }
    setPassMsg('Password successfully updated!');
    setCurrentPass('');
    setNewPass('');
    setTimeout(() => setPassMsg(''), 3000);
  };

  const initials = currentUser.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="min-h-screen bg-stone-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-stone-900 tracking-tight">Student Profile</h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Manage your NBKR student details, contact information, and security
          </p>
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-6">
          {/* Avatar and basic info */}
          <div className="flex items-center gap-4 pb-6 border-b border-stone-100">
            <div className="w-16 h-16 rounded-2xl bg-orange-600 text-white font-bold text-xl flex items-center justify-center shadow-xs">
              {initials}
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900">{currentUser.name}</h2>
              <p className="text-xs text-stone-500">{currentUser.email}</p>
              <div className="mt-1 flex items-center gap-2 text-xs">
                <span className="font-semibold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md">
                  {currentUser.role.toUpperCase()}
                </span>
                {currentUser.rollNumber && (
                  <span className="font-token font-bold text-stone-700 bg-stone-100 px-2 py-0.5 rounded-md">
                    {currentUser.rollNumber}
                  </span>
                )}
              </div>
            </div>
          </div>

          {savedSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Profile details updated successfully!</span>
            </div>
          )}

          {/* Edit Form */}
          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>
            </div>

            {/* Read-Only Academic Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-500 mb-1">
                  Roll Number (Fixed)
                </label>
                <input
                  type="text"
                  disabled
                  value={currentUser.rollNumber || '21NB1A0542'}
                  className="w-full px-3 py-2 text-sm border border-stone-200 bg-stone-100/70 text-stone-500 rounded-lg cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 mb-1">
                  Department (Fixed)
                </label>
                <input
                  type="text"
                  disabled
                  value={currentUser.department || 'Computer Science & Engineering'}
                  className="w-full px-3 py-2 text-sm border border-stone-200 bg-stone-100/70 text-stone-500 rounded-lg cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Year of Study
              </label>
              <select
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
              >
                <option value="1st Year">1st Year</option>
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year</option>
              </select>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Profile Changes</span>
              </button>
            </div>
          </form>

          {/* Change Password Box */}
          <div className="pt-6 border-t border-stone-100 space-y-3">
            <h3 className="font-bold text-stone-900 text-sm">Security & Password</h3>
            {passMsg && (
              <p className="text-xs font-semibold text-emerald-700 bg-emerald-50 p-2 rounded-lg">
                {passMsg}
              </p>
            )}
            <form onSubmit={handlePasswordChange} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="password"
                  placeholder="Current Password"
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  className="px-3 py-2 text-xs border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
                <input
                  type="password"
                  placeholder="New Password"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="px-3 py-2 text-xs border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-1.5 border border-stone-300 hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-lg cursor-pointer"
              >
                Update Password
              </button>
            </form>
          </div>

          {/* Logout Action */}
          <div className="pt-6 border-t border-stone-100 flex items-center justify-between">
            <span className="text-xs text-stone-400">
              Account created: {new Date(currentUser.createdAt).toLocaleDateString()}
            </span>

            <button
              type="button"
              onClick={() => setLogoutModal(true)}
              className="px-4 py-2 border border-red-200 text-red-600 hover:bg-red-50 text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </div>

      {/* Logout Confirmation Modal */}
      {logoutModal && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl space-y-4">
            <h3 className="font-bold text-stone-900 text-base">Sign out of NBKRCN?</h3>
            <p className="text-xs text-stone-500">
              You will need to sign in again to place orders and view your digital tokens.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setLogoutModal(false)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  logout();
                  navigate('/');
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
