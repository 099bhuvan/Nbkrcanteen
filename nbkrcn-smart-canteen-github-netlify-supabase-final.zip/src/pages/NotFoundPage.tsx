import React from 'react';
import { UtensilsCrossed, ArrowRight } from 'lucide-react';

interface NotFoundPageProps {
  navigate: (route: string) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ navigate }) => {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full text-center space-y-5 bg-white p-8 sm:p-12 rounded-3xl border border-stone-200 shadow-xs">
        <div className="w-16 h-16 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center mx-auto shadow-xs">
          <UtensilsCrossed className="w-8 h-8" />
        </div>

        <div className="space-y-1">
          <span className="font-token font-bold text-3xl text-orange-600 block">404</span>
          <h2 className="text-xl font-bold text-stone-900 tracking-tight">
            Looks like this page is out of stock!
          </h2>
          <p className="text-xs text-stone-500 leading-relaxed">
            The page you're looking for doesn't exist on the NBKRCN campus portal or might have moved.
          </p>
        </div>

        <button
          onClick={() => navigate('/dashboard')}
          className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors inline-flex items-center gap-2 cursor-pointer"
        >
          <span>Return to Menu</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
