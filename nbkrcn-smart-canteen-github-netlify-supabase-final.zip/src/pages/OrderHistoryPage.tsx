import React, { useState, useMemo } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { Order } from '../types';
import { RotateCcw, Clock, Calendar, CheckCircle2, XCircle, Search, ArrowRight, Package } from 'lucide-react';

interface OrderHistoryPageProps {
  navigate: (route: string) => void;
}

export const OrderHistoryPage: React.FC<OrderHistoryPageProps> = ({ navigate }) => {
  const { orders, currentUser, reorder } = useCanteen();

  const [statusFilter, setStatusFilter] = useState<'all' | 'collected' | 'active' | 'cancelled'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter orders for current student
  const studentOrders = useMemo(() => {
    return orders.filter((o) => {
      // If admin/staff is viewing or student, match studentId if student
      if (currentUser?.role === 'student' && o.studentId !== currentUser.id) {
        return false;
      }

      // Status filter
      if (statusFilter === 'collected' && o.status !== 'collected') return false;
      if (statusFilter === 'cancelled' && o.status !== 'cancelled' && o.status !== 'rejected') return false;
      if (statusFilter === 'active' && (o.status === 'collected' || o.status === 'cancelled' || o.status === 'rejected')) {
        return false;
      }

      // Search token or item name
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesToken = o.tokenNumber.toLowerCase().includes(q);
        const matchesItem = o.items.some((i) => i.name.toLowerCase().includes(q));
        if (!matchesToken && !matchesItem) return false;
      }

      return true;
    });
  }, [orders, currentUser, statusFilter, searchQuery]);

  const handleReorder = (order: Order) => {
    reorder(order);
    navigate('/cart');
  };

  const formatDateTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-stone-900 tracking-tight">Order History</h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Review your past canteen meals, receipts, and 1-click reorder your favorites
          </p>
        </div>

        {/* Filter bar */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by token or dish name..."
              className="w-full pl-9 pr-3 py-2 bg-white text-xs border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
            />
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-stone-200/60 rounded-lg text-xs w-full sm:w-auto">
            {(['all', 'active', 'collected', 'cancelled'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setStatusFilter(filter)}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md font-semibold capitalize transition-colors cursor-pointer ${
                  statusFilter === filter
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        {/* Orders list */}
        {studentOrders.length === 0 ? (
          <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
              <Package className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-stone-900 text-base">No Orders Found</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              You haven't placed any canteen orders matching this criteria yet.
            </p>
            <button
              onClick={() => navigate('/dashboard')}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer"
            >
              Browse Menu & Order
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {studentOrders.map((order) => {
              const isCollected = order.status === 'collected';
              const isCancelled = order.status === 'cancelled' || order.status === 'rejected';

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4 hover:border-orange-200 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
                    <div className="flex items-center gap-3">
                      <span className="font-token font-bold text-base text-stone-900 bg-stone-100 px-2.5 py-1 rounded-md">
                        {order.tokenNumber}
                      </span>
                      <div className="text-xs text-stone-500">
                        <span>{formatDateTime(order.createdAt)}</span>
                        <span className="mx-1.5">·</span>
                        <span>Pickup: {order.scheduledPickupTime}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-semibold px-2.5 py-0.5 rounded-full capitalize ${
                          isCollected
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : isCancelled
                            ? 'bg-red-50 text-red-800 border border-red-200'
                            : 'bg-orange-50 text-orange-800 border border-orange-200'
                        }`}
                      >
                        {order.status}
                      </span>
                    </div>
                  </div>

                  {/* Items summary */}
                  <div className="space-y-1.5">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex items-center justify-between text-xs text-stone-700">
                        <span>
                          <strong className="text-stone-900">{item.name}</strong> × {item.quantity}
                          {item.specialInstructions && (
                            <span className="text-[11px] text-stone-400 italic ml-2">
                              ("{item.specialInstructions}")
                            </span>
                          )}
                        </span>
                        <span className="font-semibold text-stone-900 tabular-nums">
                          ₹{item.price * item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Footer with Reorder and Total */}
                  <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-stone-400">Total Paid: </span>
                      <span className="font-bold text-sm text-stone-900 tabular-nums">₹{order.total}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {order.status !== 'collected' && order.status !== 'cancelled' && (
                        <button
                          onClick={() => navigate('/orders/track')}
                          className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                        >
                          Track Status
                        </button>
                      )}

                      <button
                        onClick={() => handleReorder(order)}
                        className="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reorder</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
