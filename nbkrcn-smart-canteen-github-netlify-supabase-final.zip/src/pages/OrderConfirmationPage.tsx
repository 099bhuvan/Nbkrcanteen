import React, { useState, useEffect, useRef } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { QRCodeSVG } from 'qrcode.react';
import {
  CheckCircle2,
  Clock,
  QrCode,
  ArrowRight,
  Download,
  Share2,
  AlertCircle,
  Sparkles
} from 'lucide-react';

interface OrderConfirmationPageProps {
  navigate: (route: string) => void;
  orderId?: string | null;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({ navigate, orderId }) => {
  const { orders } = useCanteen();
  const tokenCardRef = useRef<HTMLDivElement>(null);

  // Find most recent order or specified order
  const order = orders.find((o) => o.id === orderId) || orders[0];

  const [remainingSeconds, setRemainingSeconds] = useState(
    order ? order.estimatedReadyMinutes * 60 : 600
  );

  useEffect(() => {
    if (!order) return;
    const target = new Date(order.estimatedReadyAt).getTime();

    const interval = setInterval(() => {
      const now = Date.now();
      const diff = Math.max(0, Math.floor((target - now) / 1000));
      setRemainingSeconds(diff);
    }, 1000);

    return () => clearInterval(interval);
  }, [order]);

  if (!order) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4">
        <p className="text-stone-500 text-sm">No active order confirmation found.</p>
        <button
          onClick={() => navigate('/dashboard')}
          className="mt-4 px-4 py-2 bg-orange-600 text-white rounded-lg text-xs font-semibold"
        >
          Go to Menu
        </button>
      </div>
    );
  }

  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;

  const handleDownloadQR = () => {
    // Basic print or alert for user screenshot
    window.print();
  };

  return (
    <div className="min-h-screen bg-stone-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Success Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight">
            Order Placed Successfully!
          </h1>
          <p className="text-xs text-stone-500">
            Your kitchen order is registered. Present the digital token below at the counter.
          </p>
        </div>

        {/* Digital Token Card */}
        <div
          ref={tokenCardRef}
          className="bg-white rounded-3xl border-2 border-orange-500/30 p-6 sm:p-8 shadow-md text-center space-y-6 relative overflow-hidden"
        >
          {/* Subtle top decoration */}
          <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600" />

          {/* Token Code */}
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-widest font-semibold text-stone-400">
              Your Digital Pickup Token
            </span>
            <div className="font-token font-bold text-4xl sm:text-5xl text-orange-600 tracking-wider">
              {order.tokenNumber}
            </div>
            <p className="text-xs text-stone-500 font-medium">
              Student: {order.studentName} ({order.studentRoll})
            </p>
          </div>

          {/* QR Code Container */}
          <div className="inline-block p-4 bg-white rounded-2xl border-2 border-stone-200 shadow-inner">
            <QRCodeSVG
              value={`NBKRCN_TOKEN:${order.tokenNumber}:${order.id}`}
              size={170}
              level="H"
              includeMargin={false}
              fgColor="#1C1917"
            />
          </div>

          {/* Instructions */}
          <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-3 max-w-md mx-auto text-xs text-amber-900">
            <p className="font-semibold">Counter Collection Instructions:</p>
            <p className="mt-0.5 text-stone-600">
              Show this screen or screenshot at the canteen service counter. The staff will scan or verify your token before handing over your fresh meal.
            </p>
          </div>

          {/* ETA Live Countdown Strip */}
          <div className="bg-stone-900 text-white rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-orange-600/90 flex items-center justify-center text-white shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] text-stone-400">Estimated Ready Time</p>
                <p className="text-sm font-bold text-stone-100">
                  {order.scheduledPickupTime}
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] text-stone-400 block">Countdown</span>
              <span className="font-token font-bold text-lg text-amber-400 tabular-nums">
                {minutes}m {seconds < 10 ? '0' : ''}{seconds}s
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={handleDownloadQR}
              className="px-4 py-2 border border-stone-300 hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-xl flex items-center gap-2 cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Print / Save Token</span>
            </button>

            <button
              onClick={() => navigate('/orders/track')}
              className="px-6 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-xs cursor-pointer transition-colors"
            >
              <span>Track Live Status</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Order Details Accordion / Summary */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-3">
          <h3 className="font-bold text-stone-900 text-sm">Ordered Items</h3>
          <div className="divide-y divide-stone-100">
            {order.items.map((item, idx) => (
              <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-stone-800">{item.name}</span>
                  <span className="text-stone-400 ml-2">× {item.quantity}</span>
                  {item.specialInstructions && (
                    <p className="text-[11px] text-orange-600 italic">"{item.specialInstructions}"</p>
                  )}
                </div>
                <span className="font-bold text-stone-900 tabular-nums">
                  ₹{item.price * item.quantity}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-200 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-stone-900">
              <span>Total Bill</span>
              <span className="text-sm text-orange-600 tabular-nums">₹{order.total}</span>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-stone-500 font-medium">Payment Status:</span>
              {order.paymentMethod === 'UPI' ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg font-semibold text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Paid via UPI (7702479214@fam - kull bhuvan)</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg font-semibold text-[11px]">
                  <span>Pay ₹{order.total} Cash at Counter</span>
                </span>
              )}
            </div>
            {order.upiTransactionRef && (
              <p className="text-[10px] text-stone-400 text-right">
                Ref: {order.upiTransactionRef}
              </p>
            )}
          </div>
        </div>

        {/* Return to Dashboard */}
        <div className="text-center">
          <button
            onClick={() => navigate('/dashboard')}
            className="text-xs font-semibold text-stone-500 hover:text-stone-800 cursor-pointer"
          >
            ← Order Another Item
          </button>
        </div>
      </div>
    </div>
  );
};
