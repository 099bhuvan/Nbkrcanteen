import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { FoodVisual } from '../components/FoodVisual';
import { CanteenUPIQRCode } from '../components/CanteenUPIQRCode';
import {
  ArrowLeft,
  Plus,
  Minus,
  Trash2,
  Clock,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  ArrowRight,
  AlertTriangle,
  QrCode,
  Banknote,
  CheckCircle2
} from 'lucide-react';

interface CartPageProps {
  navigate: (route: string) => void;
  onOrderPlaced: (orderId: string) => void;
}

export const CartPage: React.FC<CartPageProps> = ({ navigate, onOrderPlaced }) => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    updateCartInstructions,
    clearCart,
    cartCount,
    cartSubtotal,
    cartPackagingFee,
    cartTotal,
    placeOrder,
    menuItems,
  } = useCanteen();

  const [pickupTime, setPickupTime] = useState('ASAP (Ready in ~10-15 mins)');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Cash'>('UPI');
  const [upiUtr, setUpiUtr] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Check if any cart item has become out of stock
  const outOfStockCartItems = cart.filter((c) => {
    const liveItem = menuItems.find((m) => m.id === c.menuItem.id);
    return liveItem && liveItem.availability === 'out_of_stock';
  });

  const pickupOptions = [
    'ASAP (Ready in ~10-15 mins)',
    'Morning Break (10:30 AM)',
    'Lunch Bell (12:45 PM)',
    'Afternoon Break (03:15 PM)',
    'Evening Snack (04:30 PM)',
  ];

  const handleCheckout = () => {
    if (cart.length === 0 || outOfStockCartItems.length > 0) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const newOrder = placeOrder(pickupTime, paymentMethod, upiUtr);
      setIsSubmitting(false);
      if (newOrder) {
        onOrderPlaced(newOrder.id);
        navigate('/orders/confirm');
      }
    }, 400);
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full text-center space-y-4 bg-white p-8 rounded-2xl border border-stone-200 shadow-xs">
          <div className="w-16 h-16 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-stone-900">Your Cart is Empty</h2>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            You haven't added any delicious canteen items yet. Browse our live menu and order ahead before the break!
          </p>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors inline-flex items-center gap-2 cursor-pointer"
          >
            <span>Browse Live Menu</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Navigation & Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate('/dashboard')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Continue Shopping</span>
          </button>

          <button
            onClick={clearCart}
            className="text-xs text-red-600 hover:text-red-700 font-semibold cursor-pointer"
          >
            Clear Cart
          </button>
        </div>

        <div>
          <h1 className="text-2xl font-bold text-stone-900 tracking-tight">Your Order Cart</h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Review items, add special kitchen instructions, and select campus pickup time
          </p>
        </div>

        {/* Warning if items went out of stock */}
        {outOfStockCartItems.length > 0 && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Item Availability Changed</p>
              <p className="mt-0.5 text-red-700">
                The following item(s) are now sold out in the kitchen:{' '}
                <strong>{outOfStockCartItems.map((c) => c.menuItem.name).join(', ')}</strong>.
                Please remove them to proceed with your order.
              </p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Cart Items List */}
          <div className="lg:col-span-7 space-y-4">
            {cart.map((cartItem) => {
              const liveItem = menuItems.find((m) => m.id === cartItem.menuItem.id) || cartItem.menuItem;
              const isUnavailable = liveItem.availability === 'out_of_stock';

              return (
                <div
                  key={cartItem.menuItem.id}
                  className={`bg-white rounded-xl border p-4 shadow-xs space-y-3 transition-colors ${
                    isUnavailable ? 'border-red-300 bg-red-50/30' : 'border-stone-200'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    {/* Visual thumbnail */}
                    <div className="w-20 h-20 shrink-0">
                      <FoodVisual item={liveItem} size="sm" className="w-20 h-20" />
                    </div>

                    {/* Item Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-bold text-stone-900 text-sm">{liveItem.name}</h3>
                          <p className="text-[11px] text-stone-400 capitalize">{liveItem.category}</p>
                        </div>
                        <span className="font-bold text-sm text-stone-900 tabular-nums shrink-0">
                          ₹{liveItem.price * cartItem.quantity}
                        </span>
                      </div>

                      {/* Price Per Unit & Stepper */}
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-stone-500 tabular-nums">
                          ₹{liveItem.price} each
                        </span>

                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1.5 bg-stone-100 rounded-lg p-1">
                            <button
                              onClick={() => updateCartQuantity(cartItem.menuItem.id, -1)}
                              className="w-6 h-6 rounded-md bg-white hover:bg-stone-200 text-stone-800 flex items-center justify-center font-bold text-xs shadow-xs cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-6 text-center font-bold text-xs text-stone-900 tabular-nums">
                              {cartItem.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(cartItem.menuItem.id, 1)}
                              className="w-6 h-6 rounded-md bg-orange-600 hover:bg-orange-700 text-white flex items-center justify-center font-bold text-xs shadow-xs cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            onClick={() => removeFromCart(cartItem.menuItem.id)}
                            title="Remove item"
                            className="p-1.5 text-stone-400 hover:text-red-600 rounded-md transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Special instruction inline input */}
                  <div className="pt-2 border-t border-stone-100">
                    <input
                      type="text"
                      placeholder="Special note (e.g. less spice, no sugar, extra sambar)..."
                      value={cartItem.specialInstructions || ''}
                      onChange={(e) => updateCartInstructions(cartItem.menuItem.id, e.target.value)}
                      className="w-full text-xs px-3 py-1.5 bg-stone-50 rounded-lg border border-stone-200 focus:outline-hidden focus:bg-white focus:border-orange-500"
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Pickup Scheduling & Order Summary */}
          <div className="lg:col-span-5 space-y-4">
            {/* Scheduled Pickup Time Card */}
            <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-orange-600" />
                <h3 className="font-bold text-stone-900 text-sm">Scheduled Pickup Window</h3>
              </div>
              <p className="text-xs text-stone-500">
                Choose when you want to collect your food at the canteen counter:
              </p>

              <div className="space-y-2 pt-1">
                {pickupOptions.map((opt) => (
                  <label
                    key={opt}
                    className={`flex items-center gap-3 p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                      pickupTime === opt
                        ? 'border-orange-500 bg-orange-50/60 font-semibold text-orange-950'
                        : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="pickupTime"
                      checked={pickupTime === opt}
                      onChange={() => setPickupTime(opt)}
                      className="accent-orange-600"
                    />
                    <span>{opt}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                <h3 className="font-bold text-stone-900 text-sm">Payment Method</h3>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  UPI Instant Pay Enabled
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('UPI')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                    paymentMethod === 'UPI'
                      ? 'border-orange-500 bg-orange-50/50 ring-2 ring-orange-200'
                      : 'border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <QrCode className={`w-5 h-5 ${paymentMethod === 'UPI' ? 'text-orange-600' : 'text-stone-400'}`} />
                    {paymentMethod === 'UPI' && <CheckCircle2 className="w-4 h-4 text-orange-600" />}
                  </div>
                  <div>
                    <p className="font-bold text-xs text-stone-900">UPI QR / Mobile</p>
                    <p className="text-[10px] text-stone-500">GPay, PhonePe, FamApp</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('Cash')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                    paymentMethod === 'Cash'
                      ? 'border-orange-500 bg-orange-50/50 ring-2 ring-orange-200'
                      : 'border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <Banknote className={`w-5 h-5 ${paymentMethod === 'Cash' ? 'text-orange-600' : 'text-stone-400'}`} />
                    {paymentMethod === 'Cash' && <CheckCircle2 className="w-4 h-4 text-orange-600" />}
                  </div>
                  <div>
                    <p className="font-bold text-xs text-stone-900">Cash on Counter</p>
                    <p className="text-[10px] text-stone-500">Pay when collecting meal</p>
                  </div>
                </button>
              </div>

              {/* If UPI is selected, display the exact UPI QR Card */}
              {paymentMethod === 'UPI' && (
                <div className="space-y-3 pt-2">
                  <div className="text-center">
                    <span className="text-xs font-semibold text-stone-700">
                      Scan Official Canteen QR to Pay ₹{cartTotal}:
                    </span>
                  </div>

                  <CanteenUPIQRCode amount={cartTotal} />

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                      UPI Ref / UTR / Transaction ID (Optional)
                    </label>
                    <input
                      type="text"
                      value={upiUtr}
                      onChange={(e) => setUpiUtr(e.target.value)}
                      placeholder="e.g. 4289... or last 4 digits"
                      className="w-full text-xs px-3 py-2 border border-stone-300 rounded-lg bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Bill Summary Card */}
            <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs space-y-4">
              <h3 className="font-bold text-stone-900 text-sm border-b border-stone-100 pb-2">
                Order Summary
              </h3>

              <div className="space-y-2 text-xs text-stone-600">
                <div className="flex items-center justify-between">
                  <span>Item Subtotal ({cartCount} {cartCount === 1 ? 'item' : 'items'})</span>
                  <span className="font-semibold text-stone-900 tabular-nums">₹{cartSubtotal}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Eco-Packaging / Cutlery</span>
                  <span className="font-semibold text-stone-900 tabular-nums">₹{cartPackagingFee}</span>
                </div>
                <div className="flex items-center justify-between text-emerald-700">
                  <span>Campus Student Queue Bypass</span>
                  <span className="font-bold">FREE</span>
                </div>
                <div className="pt-3 border-t border-stone-200 flex items-center justify-between text-sm font-bold text-stone-900">
                  <span>Total Amount</span>
                  <span className="text-base text-orange-600 tabular-nums">₹{cartTotal}</span>
                </div>
              </div>

              {/* Digital token note */}
              <div className="p-3 bg-stone-50 rounded-lg text-[11px] text-stone-500 space-y-1">
                <p className="font-semibold text-stone-700">✨ Fast Pickup Verification:</p>
                <p>
                  Upon placing the order, you will receive a unique digital token & QR code. Simply show this at the canteen collection counter.
                </p>
              </div>

              {/* Place Order CTA */}
              <button
                type="button"
                disabled={isSubmitting || outOfStockCartItems.length > 0}
                onClick={handleCheckout}
                className={`w-full py-3 px-4 rounded-xl font-bold text-sm shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                  outOfStockCartItems.length > 0
                    ? 'bg-stone-300 text-stone-500 cursor-not-allowed'
                    : 'bg-orange-600 hover:bg-orange-700 text-white active:scale-98'
                }`}
              >
                {isSubmitting ? (
                  <span>Generating Digital Token...</span>
                ) : (
                  <>
                    <span>
                      {paymentMethod === 'UPI' ? 'I Have Paid · Confirm Order' : 'Place Order (Pay on Counter)'} (₹{cartTotal})
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
