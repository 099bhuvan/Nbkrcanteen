import React, { useState, useMemo } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { MenuItem, MenuCategory, AvailabilityStatus } from '../types';
import { FoodVisual } from '../components/FoodVisual';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  Sparkles,
  ArrowLeft
} from 'lucide-react';

interface MenuManagementPageProps {
  navigate: (route: string) => void;
}

export const MenuManagementPage: React.FC<MenuManagementPageProps> = ({ navigate }) => {
  const {
    menuItems,
    updateItemAvailability,
    updateItemStock,
    batchUpdateAvailability,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    resetMenuToDefaults
  } = useCanteen();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  // Form state for Add/Edit
  const [formData, setFormData] = useState<{
    name: string;
    description: string;
    price: number;
    category: MenuCategory;
    isVeg: boolean;
    availability: AvailabilityStatus;
    stockQuantity: number;
    prepTimeMinutes: number;
    iconType: MenuItem['iconType'];
    accentColor: string;
    imageUrl?: string;
  }>({
    name: '',
    description: '',
    price: 30,
    category: 'Snacks',
    isVeg: true,
    availability: 'available',
    stockQuantity: 25,
    prepTimeMinutes: 5,
    iconType: 'samosa',
    accentColor: '#F97316',
    imageUrl: '',
  });

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [menuItems, selectedCategory, searchQuery]);

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      name: '',
      description: '',
      price: 30,
      category: 'Snacks',
      isVeg: true,
      availability: 'available',
      stockQuantity: 30,
      prepTimeMinutes: 5,
      iconType: 'samosa',
      accentColor: '#F97316',
      imageUrl: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: MenuItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      description: item.description,
      price: item.price,
      category: item.category,
      isVeg: item.isVeg,
      availability: item.availability,
      stockQuantity: item.stockQuantity,
      prepTimeMinutes: item.prepTimeMinutes,
      iconType: item.iconType,
      accentColor: item.accentColor,
      imageUrl: item.imageUrl || '',
    });
    setIsModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    if (editingItem) {
      updateMenuItem(editingItem.id, formData);
    } else {
      addMenuItem(formData);
    }
    setIsModalOpen(false);
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredItems.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredItems.map((i) => i.id));
    }
  };

  const toggleSelectItem = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleBatchStatus = (status: AvailabilityStatus) => {
    if (selectedIds.length === 0) return;
    batchUpdateAvailability(selectedIds, status);
    setSelectedIds([]);
  };

  return (
    <div className="min-h-screen bg-stone-50 py-6 px-4 sm:px-6 lg:px-8 space-y-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/staff/dashboard')}
              className="p-2 border border-stone-200 bg-white rounded-lg hover:bg-stone-50 text-stone-600 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-stone-900 tracking-tight">
                Menu & Kitchen Stock Management
              </h1>
              <p className="text-xs text-stone-500">
                Update live food availability, portion counts, and item prices in real-time
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={resetMenuToDefaults}
              className="px-3 py-2 border border-stone-300 hover:bg-stone-100 rounded-lg text-xs font-semibold text-stone-700 flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>

            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Item</span>
            </button>
          </div>
        </div>

        {/* Filters & Batch Actions Bar */}
        <div className="bg-white rounded-2xl border border-stone-200 p-4 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            {/* Search */}
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dish by name..."
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
              />
            </div>

            {/* Category Segmented */}
            <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              {['All', 'Breakfast', 'Meals', 'Snacks', 'Beverages', 'Combos'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-stone-900 text-white'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Batch update strip if items selected */}
          {selectedIds.length > 0 && (
            <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3 bg-orange-50/50 p-2.5 rounded-xl">
              <span className="text-xs font-bold text-orange-950">
                {selectedIds.length} {selectedIds.length === 1 ? 'item' : 'items'} selected
              </span>

              <div className="flex items-center gap-2">
                <span className="text-[11px] text-stone-500">Batch Set Status:</span>
                <button
                  onClick={() => handleBatchStatus('available')}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow-xs cursor-pointer"
                >
                  Available
                </button>
                <button
                  onClick={() => handleBatchStatus('limited')}
                  className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-md shadow-xs cursor-pointer"
                >
                  Limited
                </button>
                <button
                  onClick={() => handleBatchStatus('out_of_stock')}
                  className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-md shadow-xs cursor-pointer"
                >
                  Out of Stock
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Table of Menu Items */}
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="py-3 px-4 w-10">
                    <input
                      type="checkbox"
                      checked={selectedIds.length > 0 && selectedIds.length === filteredItems.length}
                      onChange={toggleSelectAll}
                      className="rounded accent-orange-600"
                    />
                  </th>
                  <th className="py-3 px-4">Item & Visual</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Price</th>
                  <th className="py-3 px-4">Live Availability</th>
                  <th className="py-3 px-4">Stock Qty</th>
                  <th className="py-3 px-4">Prep Time</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-stone-100">
                {filteredItems.map((item) => {
                  const isChecked = selectedIds.includes(item.id);

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-stone-50/70 transition-colors ${
                        item.availability === 'out_of_stock' ? 'bg-stone-50/40 text-stone-500' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelectItem(item.id)}
                          className="rounded accent-orange-600"
                        />
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <FoodVisual item={item} size="sm" className="w-12 h-12 rounded-lg" />
                          <div>
                            <p className="font-bold text-stone-900 text-sm">{item.name}</p>
                            <p className="text-[11px] text-stone-400 line-clamp-1">{item.description}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-medium text-stone-600">
                        {item.category}
                      </td>

                      <td className="py-3 px-4 font-bold text-stone-900 tabular-nums">
                        ₹{item.price}
                      </td>

                      {/* Inline Availability Selector */}
                      <td className="py-3 px-4">
                        <select
                          value={item.availability}
                          onChange={(e) => updateItemAvailability(item.id, e.target.value as AvailabilityStatus)}
                          className={`text-xs font-semibold py-1 px-2.5 rounded-lg border cursor-pointer ${
                            item.availability === 'available'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : item.availability === 'limited'
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : 'bg-red-50 text-red-800 border-red-300'
                          }`}
                        >
                          <option value="available">🟢 Available</option>
                          <option value="limited">🟠 Limited Stock</option>
                          <option value="out_of_stock">🔴 Out of Stock</option>
                        </select>
                      </td>

                      {/* Inline Stock Quantity Editor */}
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min={0}
                          value={item.stockQuantity}
                          onChange={(e) => updateItemStock(item.id, parseInt(e.target.value) || 0)}
                          className="w-16 px-2 py-1 border border-stone-300 rounded-md text-center tabular-nums text-xs font-semibold"
                        />
                      </td>

                      <td className="py-3 px-4 text-stone-500 tabular-nums">
                        ~{item.prepTimeMinutes} mins
                      </td>

                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors cursor-pointer"
                          title="Edit Item Details"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete ${item.name} from canteen menu?`)) {
                              deleteMenuItem(item.id);
                            }
                          }}
                          className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors cursor-pointer"
                          title="Delete Item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add / Edit Item Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-stone-900 text-lg">
              {editingItem ? 'Edit Canteen Dish' : 'Add New Dish to Menu'}
            </h3>

            <form onSubmit={handleSaveModal} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Item Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Masala Dosa, Paneer Roll"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Short description of ingredients and presentation..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as MenuCategory })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg bg-white"
                  >
                    <option value="Breakfast">Breakfast</option>
                    <option value="Meals">Meals</option>
                    <option value="Snacks">Snacks</option>
                    <option value="Beverages">Beverages</option>
                    <option value="Combos">Combos</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Price (₹) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Initial Stock Count
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formData.stockQuantity}
                    onChange={(e) => setFormData({ ...formData, stockQuantity: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Prep Time (Mins)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.prepTimeMinutes}
                    onChange={(e) => setFormData({ ...formData, prepTimeMinutes: parseInt(e.target.value) || 5 })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Availability
                  </label>
                  <select
                    value={formData.availability}
                    onChange={(e) => setFormData({ ...formData, availability: e.target.value as AvailabilityStatus })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg bg-white"
                  >
                    <option value="available">Available</option>
                    <option value="limited">Limited</option>
                    <option value="out_of_stock">Out of Stock</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Visual Icon Illustration
                  </label>
                  <select
                    value={formData.iconType}
                    onChange={(e) => setFormData({ ...formData, iconType: e.target.value as MenuItem['iconType'] })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg bg-white"
                  >
                    <option value="dosa">Dosa / South Indian</option>
                    <option value="samosa">Samosa / Puffs</option>
                    <option value="biryani">Biryani / Rice</option>
                    <option value="thali">Meals Thali</option>
                    <option value="chai">Cutting Chai</option>
                    <option value="coffee">Filter Coffee</option>
                    <option value="sandwich">Vada Pav / Burger</option>
                    <option value="juice">Fresh Juice</option>
                    <option value="combo">Combo Platter</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Food Photo URL (Real Image)
                </label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={formData.imageUrl || ''}
                  onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg"
                />
                <p className="text-[11px] text-stone-400 mt-1">
                  Provide an authentic food photo URL to display on student menu cards
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-lg shadow-xs cursor-pointer"
                >
                  {editingItem ? 'Save Changes' : 'Add Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
