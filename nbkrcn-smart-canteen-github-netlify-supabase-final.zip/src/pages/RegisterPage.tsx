import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import {
  AlertCircle,
  CheckCircle2,
  Info,
  ArrowRight,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

interface RegisterPageProps {
  navigate: (route: string) => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({ navigate }) => {
  const { registerStudent, isUsernameAvailable } = useCanteen();

  const [formData, setFormData] = useState({
    name: '',
    username: '',
    rollNumber: '',
    department: 'Computer Science & Engineering',
    year: '3rd Year',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const departments = [
    'Computer Science & Engineering',
    'AI & Data Science',
    'Electronics & Communication',
    'Electrical & Electronics',
    'Mechanical Engineering',
    'Civil Engineering',
    'Information Technology',
  ];

  const years = ['1st Year', '2nd Year', '3rd Year', '4th Year'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUsername = formData.username.trim().toLowerCase();

    if (
      !formData.name.trim() ||
      !cleanUsername ||
      !formData.rollNumber.trim() ||
      !formData.email.trim() ||
      !formData.password.trim()
    ) {
      setError('Please fill in all required fields.');
      return;
    }

    if (cleanUsername.length < 3) {
      setError('Username must be at least 3 characters long.');
      return;
    }

    if (!isUsernameAvailable(cleanUsername)) {
      setError(`Username "${cleanUsername}" is already taken by another student. Please choose a different unique username.`);
      return;
    }

    if (formData.password.length < 6) {
      setError('Passwords must be at least 6 characters.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match. Please re-enter your password.');
      return;
    }

    const res = registerStudent({
      name: formData.name.trim(),
      username: cleanUsername,
      password: formData.password,
      email: formData.email.trim(),
      rollNumber: formData.rollNumber.trim().toUpperCase(),
      department: formData.department,
      year: formData.year,
      phone: formData.phone.trim() || '+91 98480 00000',
    });

    if (res.success) {
      setSuccess(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 1000);
    } else {
      setError(res.message || 'Could not complete registration. Please check your details.');
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col justify-between text-stone-900 font-sans selection:bg-[#F3A847] selection:text-black">
      {/* Top Header Section */}
      <div className="pt-6 sm:pt-8 pb-12 px-4 flex flex-col items-center">
        {/* Amazon-style NBKRCN Logo with Smile Arc */}
        <div className="mb-6 flex flex-col items-center">
          <button
            onClick={() => navigate('/')}
            className="cursor-pointer group focus-visible:outline-hidden"
            title="NBKRCN Smart Canteen Home"
          >
            <div className="flex items-center gap-1.5 select-none">
              <span className="font-heading font-black text-3xl sm:text-4xl tracking-tighter text-stone-900">
                nbkrcn
              </span>
              <span className="text-xs font-bold text-[#E77600] self-start mt-1">.in</span>
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider ml-1 px-1.5 py-0.5 rounded bg-stone-100">
                canteen
              </span>
            </div>
            {/* Amazon Smile Arc Vector */}
            <svg
              className="w-28 sm:w-32 h-4 -mt-1 text-[#FF9900]"
              viewBox="0 0 120 18"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M4 8 C40 18 80 18 116 6"
                stroke="#FF9900"
                strokeWidth="3.2"
                strokeLinecap="round"
              />
              <path
                d="M109 4 L117 7 L114 13 Z"
                fill="#FF9900"
              />
            </svg>
          </button>
        </div>

        {/* Amazon Error Banner */}
        {error && (
          <div className="w-full max-w-[360px] sm:max-w-[400px] mb-4 p-4 border border-[#CC0C39] bg-white rounded-lg flex items-start gap-3 shadow-xs animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 text-[#CC0C39] shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-[#CC0C39] leading-tight">There was a problem</h4>
              <p className="text-xs text-stone-700 mt-1 leading-normal">{error}</p>
            </div>
          </div>
        )}

        {/* Amazon Signature Create Account Card */}
        <div className="w-full max-w-[360px] sm:max-w-[400px] bg-white border border-stone-300 rounded-lg p-6 sm:p-7 shadow-xs">
          <h1 className="text-2xl sm:text-[28px] font-normal text-stone-900 tracking-tight mb-5">
            Create Account
          </h1>

          {success ? (
            <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-3">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
              <h3 className="text-base font-bold text-emerald-950">Student Account Created!</h3>
              <p className="text-xs text-emerald-800 leading-relaxed">
                Welcome, <strong>{formData.name}</strong>. Your unique username <strong>@{formData.username.toLowerCase()}</strong> is registered.
              </p>
              <div className="pt-2 flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-700">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span>Redirecting to canteen menu...</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Your Name */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Your name
                </label>
                <input
                  type="text"
                  required
                  placeholder="First and last name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-1.5 text-sm rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                />
              </div>

              {/* Unique Username */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-stone-900">
                    Choose unique username
                  </label>
                  {formData.username.trim().length >= 3 && (
                    <span
                      className={`text-[11px] font-bold flex items-center gap-1 ${
                        isUsernameAvailable(formData.username) ? 'text-emerald-700' : 'text-[#CC0C39]'
                      }`}
                    >
                      {isUsernameAvailable(formData.username) ? '✓ Available' : '✕ Taken'}
                    </span>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1.5 text-stone-400 font-token text-xs select-none">@</span>
                  <input
                    type="text"
                    required
                    placeholder="e.g. arjun_cs or ravi99"
                    value={formData.username}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''),
                      })
                    }
                    className="w-full pl-7 pr-3 py-1.5 text-sm rounded border border-stone-400 bg-white font-token focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner lowercase"
                  />
                </div>
                <p className="text-[10px] text-stone-500 mt-1">
                  Must be unique across students. You will use this username to sign in.
                </p>
              </div>

              {/* College Email */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  College Email
                </label>
                <input
                  type="email"
                  required
                  placeholder="student.name@nbkrcn.edu.in"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-1.5 text-sm rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                />
              </div>

              {/* Roll Number */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Roll Number (ID)
                </label>
                <input
                  type="text"
                  required
                  placeholder="23NB1A0589"
                  value={formData.rollNumber}
                  onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-1.5 text-sm rounded border border-stone-400 bg-white uppercase font-token focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                />
              </div>

              {/* Department & Year */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-stone-900 mb-1">
                    Department
                  </label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-2 py-1.5 text-xs rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600]"
                  >
                    {departments.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-900 mb-1">
                    Year
                  </label>
                  <select
                    value={formData.year}
                    onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                    className="w-full px-2 py-1.5 text-xs rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600]"
                  >
                    {years.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Mobile Phone (optional) */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Mobile number (optional)
                </label>
                <input
                  type="tel"
                  placeholder="+91 98480 12345"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-1.5 text-sm rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="At least 6 characters"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-3 py-1.5 text-sm rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                />
                <div className="flex items-center gap-1.5 text-[11px] text-stone-600 mt-1">
                  <Info className="w-3.5 h-3.5 text-[#007185] shrink-0" />
                  <span>Passwords must be at least 6 characters.</span>
                </div>
              </div>

              {/* Re-enter password */}
              <div>
                <label className="block text-xs font-bold text-stone-900 mb-1">
                  Re-enter password
                </label>
                <input
                  type="password"
                  required
                  placeholder="Re-enter password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="w-full px-3 py-1.5 text-sm rounded border border-stone-400 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#e77600]/30 focus:border-[#e77600] transition-shadow shadow-inner"
                />
              </div>

              {/* Amazon Primary Amber Button */}
              <button
                type="submit"
                className="w-full py-2 px-3 text-sm font-normal text-stone-900 bg-[#FFD814] hover:bg-[#F7CA00] active:bg-[#F0B800] border border-[#FCD200] rounded-lg shadow-xs transition-colors cursor-pointer text-center mt-2"
              >
                Create your NBKRCN account
              </button>

              {/* Amazon Legal Notice */}
              <p className="text-[11px] text-stone-600 leading-normal pt-1">
                By creating an account, you agree to NBKRCN Canteen's{' '}
                <a href="#conditions" className="text-[#007185] hover:text-[#C7511F] hover:underline">
                  Conditions of Use
                </a>{' '}
                and{' '}
                <a href="#privacy" className="text-[#007185] hover:text-[#C7511F] hover:underline">
                  Privacy Notice
                </a>
                .
              </p>

              {/* Divider & Already have an account */}
              <div className="pt-4 border-t border-stone-200 text-xs text-stone-700">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/login/student')}
                  className="text-[#007185] hover:text-[#C7511F] hover:underline font-semibold cursor-pointer inline-flex items-center gap-0.5"
                >
                  <span>Sign in</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Amazon Footer */}
      <footer className="w-full py-8 border-t border-stone-200 bg-gradient-to-b from-stone-50/50 to-stone-100/60 text-center text-xs text-stone-600">
        <div className="max-w-md mx-auto space-y-3 px-4">
          <div className="flex items-center justify-center gap-6 text-[11px] text-[#007185]">
            <a href="#conditions" className="hover:text-[#C7511F] hover:underline">
              Conditions of Use
            </a>
            <a href="#privacy" className="hover:text-[#C7511F] hover:underline">
              Privacy Notice
            </a>
            <a href="#help" className="hover:text-[#C7511F] hover:underline">
              Help
            </a>
          </div>

          <p className="text-[11px] text-stone-500">
            © 2026, NBKR Institute of Science & Technology, Inc. or its affiliates
          </p>
        </div>
      </footer>
    </div>
  );
};
