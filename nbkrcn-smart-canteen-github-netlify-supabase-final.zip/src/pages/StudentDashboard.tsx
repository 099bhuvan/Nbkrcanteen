import React, { useState, useMemo, useEffect } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { MenuCategory, MenuItem } from '../types';
import { FoodVisual } from '../components/FoodVisual';
import { CanteenUPIQRCode } from '../components/CanteenUPIQRCode';
import {
  Search,
  Plus,
  Minus,
  ShoppingBag,
  Clock,
  Sparkles,
  ArrowRight,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  ChefHat,
  QrCode,
  X
} from 'lucide-react';

interface StudentDashboardProps {
  navigate: (route: string) => void;
}

const CATEGORIES: ('All' | MenuCategory)[] = ['All', 'Breakfast', 'Meals', 'Snacks', 'Beverages', 'Combos'];

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ navigate }) => {
  const {
    menuItems,
    cart,
    addToCart,
    updateCartQuantity,
    cartCount,
    cartTotal,
    activeStudentOrder,
    currentUser
  } = useCanteen();

  const [selectedCategory, setSelectedCategory] = useState<'All' | MenuCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [vegOnly, setVegOnly] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [instructionModalItem, setInstructionModalItem] = useState<MenuItem | null>(null);
  const [customNote, setCustomNote] = useState('');
  const [showCounterQRModal, setShowCounterQRModal] = useState(false);

  // Active order ETA countdown
  const [timeLeftStr, setTimeLeftStr] = useState<string>('');

  useEffect(() => {
    if (!activeStudentOrder) return;

    const updateTimer = () => {
      const target = new Date(activeStudentOrder.estimatedReadyAt).getTime();
      const now = Date.now();
      const diffSec = Math.max(0, Math.floor((target - now) / 1000));

      if (diffSec <= 0) {
        setTimeLeftStr('Ready soon!');
      } else {
        const m = Math.floor(diffSec / 60);
        const s = diffSec % 60;
        setTimeLeftStr(`${m}m ${s < 10 ? '0' : ''}${s}s`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [activeStudentOrder]);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  // Filter menu items
  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      const matchQuery =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchVeg = !vegOnly || item.isVeg;
      return matchCat && matchQuery && matchVeg;
    });
  }, [menuItems, selectedCategory, searchQuery, vegOnly]);

  const getCartQuantity = (itemId: string) => {
    const found = cart.find((c) => c.menuItem.id === itemId);
    return found ? found.quantity : 0;
  };

  const handleOpenNoteModal = (item: MenuItem) => {
    const existing = cart.find((c) => c.menuItem.id === item.id);
    setCustomNote(existing?.specialInstructions || '');
    setInstructionModalItem(item);
  };

  const handleSaveNote = () => {
    if (instructionModalItem) {
      addToCart(instructionModalItem, 1, customNote);
      setInstructionModalItem(null);
      setCustomNote('');
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 pb-24">
      {/* 1. Active Order Banner (Sticky at top if active order exists) */}
      {activeStudentOrder && (
        <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-orange-700 text-white shadow-md sticky top-16 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0">
                <ChefHat className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-token font-bold text-sm tracking-wider bg-black/20 px-2 py-0.5 rounded">
                    {activeStudentOrder.tokenNumber}
                  </span>
                  <span className="text-xs uppercase tracking-wider font-semibold px-2 py-0.5 rounded bg-white/20 capitalize">
                    {activeStudentOrder.status === 'placed' && 'Placed'}
                    {activeStudentOrder.status === 'accepted' && 'Accepted by Kitchen'}
                    {activeStudentOrder.status === 'preparing' && 'Preparing now'}
                    {activeStudentOrder.status === 'ready' && 'Ready for Pickup!'}
                  </span>
                </div>
                <p className="text-xs text-orange-100 mt-0.5 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>ETA: <strong className="text-white">{timeLeftStr}</strong></span>
                  <span>·</span>
                  <span>{activeStudentOrder.items.length} {activeStudentOrder.items.length === 1 ? 'item' : 'items'}</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => navigate('/orders/track')}
              className="px-4 py-1.5 bg-white text-orange-700 hover:bg-orange-50 font-bold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>View Token & Status</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Welcome Greeting & Live Refresh */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-stone-900 tracking-tight">
              Hello, {currentUser?.name?.split(' ')[0] || 'Student'} 👋
            </h1>
            <p className="text-xs text-stone-500 mt-0.5">
              Live Canteen Kitchen · Break pickup timings available
            </p>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <button
              onClick={() => setShowCounterQRModal(true)}
              className="px-3 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              title="View Canteen Counter UPI QR Code"
            >
              <QrCode className="w-3.5 h-3.5 text-orange-600" />
              <span>Counter QR</span>
            </button>

            <button
              onClick={handleManualRefresh}
              className={`p-2 rounded-lg border border-stone-200 bg-white text-stone-600 hover:text-stone-900 text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-transform ${
                isRefreshing ? 'opacity-70 rotate-180 duration-500' : ''
              }`}
              title="Refresh Live Availability"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh Menu</span>
            </button>

            {/* Quick status summary chip */}
            <div className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Kitchen Serving</span>
            </div>
          </div>
        </div>

        {/* Search & Category Filter Controls */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search food by name (e.g. Masala Dosa, Samosa, Biryani)..."
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-stone-300 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 shadow-xs placeholder:text-stone-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Pure Veg Toggle */}
            <button
              type="button"
              onClick={() => setVegOnly(!vegOnly)}
              className={`px-3 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
                vegOnly
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
              }`}
            >
              <div className="w-3.5 h-3.5 border border-current flex items-center justify-center rounded-xs">
                <div className="w-1.5 h-1.5 rounded-full bg-current" />
              </div>
              <span className="whitespace-nowrap">Pure Veg Only</span>
            </button>
          </div>

          {/* Category Tabs (Segmented control style, no pill badges) */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-stone-200">
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                    isSelected
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-2xl border border-stone-200 p-8 space-y-3">
            <div className="w-12 h-12 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center mx-auto">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-stone-900">No menu items found</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              We couldn't find any dishes matching "{searchQuery}". Try selecting another category or clear your search.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setVegOnly(false);
              }}
              className="px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg cursor-pointer hover:bg-stone-800"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filteredItems.map((item) => {
              const qtyInCart = getCartQuantity(item.id);
              const isOutOfStock = item.availability === 'out_of_stock';
              const isLimited = item.availability === 'limited';

              return (
                <div
                  key={item.id}
                  className={`relative flex flex-col justify-between bg-white rounded-2xl border transition-all duration-200 shadow-xs hover:shadow-md ${
                    isOutOfStock
                      ? 'border-stone-200 opacity-60 bg-stone-50/50'
                      : 'border-stone-200 hover:border-orange-300'
                  }`}
                >
                  <div className="p-4 space-y-3">
                    {/* Visual Asset (SVG Illustration Handcrafted) */}
                    <div className="relative">
                      <FoodVisual item={item} size="md" />

                      {/* Out of Stock Overlay */}
                      {isOutOfStock && (
                        <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-2xs rounded-xl flex items-center justify-center">
                          <span className="px-3 py-1 bg-red-600 text-white font-bold text-xs uppercase tracking-wider rounded-md shadow-sm">
                            Sold Out Today
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Header info */}
                    <div>
                      <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                        <span className="font-medium text-stone-400">{item.category}</span>
                        {/* Live availability indicator */}
                        <div className="flex items-center gap-1.5">
                          {item.availability === 'available' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                              <span className="w-2 h-2 rounded-full bg-emerald-500" />
                              Available
                            </span>
                          )}
                          {isLimited && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700">
                              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                              Only {item.stockQuantity} left
                            </span>
                          )}
                          {isOutOfStock && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600">
                              <span className="w-2 h-2 rounded-full bg-red-500" />
                              Out of stock
                            </span>
                          )}
                        </div>
                      </div>

                      <h3 className="font-heading font-bold text-stone-900 text-base leading-snug">
                        {item.name}
                      </h3>
                      <p className="text-stone-500 text-xs mt-1 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  {/* Card Footer: Price & Add / Stepper CTA */}
                  <div className="p-4 pt-0 border-t border-stone-100 flex items-center justify-between mt-auto">
                    <div>
                      <span className="text-[11px] text-stone-400 block">Price</span>
                      <span className="font-bold text-lg text-stone-900 tabular-nums">
                        ₹{item.price}
                      </span>
                    </div>

                    <div>
                      {isOutOfStock ? (
                        <button
                          disabled
                          className="px-3.5 py-1.5 text-xs font-semibold text-stone-400 bg-stone-100 rounded-lg cursor-not-allowed"
                        >
                          Unavailable
                        </button>
                      ) : qtyInCart > 0 ? (
                        <div className="flex items-center gap-1.5 bg-orange-50 border border-orange-200 rounded-lg p-1">
                          <button
                            onClick={() => updateCartQuantity(item.id, -1)}
                            className="w-7 h-7 rounded-md bg-white text-orange-700 hover:bg-orange-100 flex items-center justify-center font-bold text-sm shadow-xs transition-colors cursor-pointer"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="w-6 text-center font-bold text-sm text-stone-900 tabular-nums">
                            {qtyInCart}
                          </span>
                          <button
                            onClick={() => updateCartQuantity(item.id, 1)}
                            className="w-7 h-7 rounded-md bg-orange-600 text-white hover:bg-orange-700 flex items-center justify-center font-bold text-sm shadow-xs transition-colors cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => addToCart(item, 1)}
                            className="px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer active:scale-95"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                          <button
                            onClick={() => handleOpenNoteModal(item)}
                            title="Add special instructions (less spicy, etc.)"
                            className="p-2 border border-stone-200 hover:bg-stone-50 rounded-lg text-stone-400 hover:text-stone-700 transition-colors cursor-pointer text-xs"
                          >
                            ✏️
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Floating Bottom Cart Bar (Fixed on mobile / desktop bottom) */}
      {cartCount > 0 && (
        <aside
          aria-label="Floating cart summary"
          className="fixed bottom-4 inset-x-0 max-w-lg mx-auto px-4 z-40 animate-in slide-in-from-bottom-4 duration-200"
        >
          <div className="bg-stone-900 text-white rounded-2xl p-3.5 shadow-xl flex items-center justify-between border border-stone-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-600 flex items-center justify-center text-white shrink-0">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-stone-300">
                  <span className="font-bold text-white tabular-nums">{cartCount}</span> {cartCount === 1 ? 'item' : 'items'} in cart
                </p>
                <p className="text-base font-bold text-orange-400 tabular-nums">
                  ₹{cartTotal} <span className="text-[11px] font-normal text-stone-400">(incl. packaging)</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => navigate('/cart')}
              className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>View Cart & Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </aside>
      )}

      {/* Special Instruction Modal */}
      {instructionModalItem && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Special Kitchen Note</h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Customizing: <strong>{instructionModalItem.name}</strong>
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Instructions for the Chef (e.g. less spicy, extra chutney, no onion)
              </label>
              <textarea
                rows={3}
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="Type your customization instructions here..."
                className="w-full p-3 text-xs border border-stone-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setInstructionModalItem(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveNote}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Save & Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Canteen Counter UPI QR Modal */}
      {showCounterQRModal && (
        <div className="fixed inset-0 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="relative max-w-md w-full bg-stone-900 rounded-3xl p-2 shadow-2xl border border-stone-700">
            <button
              onClick={() => setShowCounterQRModal(false)}
              className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            <CanteenUPIQRCode />
          </div>
        </div>
      )}
    </div>
  );
};
