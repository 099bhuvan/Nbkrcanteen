import { createClient } from '@supabase/supabase-js';

// The publishable key is safe to ship in a browser application.
// Environment variables override these values when configured in Netlify/GitHub.
export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://spucfzlpgefanyimlwce.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_KkMmqcBP3X0XKu2uknUGIQ_i1Uxh3cd';

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});
