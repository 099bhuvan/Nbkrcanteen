import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { MenuItem, Order, OrderStatus, CartItem, UserProfile, UserRole, AvailabilityStatus } from '../types';
import { INITIAL_MENU_ITEMS, INITIAL_ORDERS, INITIAL_USERS } from '../data/initialData';
import { playOrderChime } from '../utils/audio';
import { sendBrowserNotification } from '../utils/notifications';
import { supabase } from '../lib/supabase';

interface CanteenContextType {
  // User & Auth
  currentUser: UserProfile | null;
  users: UserProfile[];
  login: (identifier: string, password?: string, role?: UserRole) => { success: boolean; message?: string };
  loginAsPreset: (role: UserRole) => void;
  logout: () => void;
  registerStudent: (details: Omit<UserProfile, 'id' | 'role' | 'createdAt' | 'status'>) => { success: boolean; message?: string };
  isUsernameAvailable: (username: string) => boolean;
  updateProfile: (updated: Partial<UserProfile>) => void;
  addStaffAccount: (name: string, email: string, role: 'staff' | 'admin') => void;
  toggleUserStatus: (userId: string) => void;

  // Menu
  menuItems: MenuItem[];
  updateItemAvailability: (id: string, availability: AvailabilityStatus) => void;
  updateItemStock: (id: string, stock: number) => void;
  batchUpdateAvailability: (itemIds: string[], availability: AvailabilityStatus) => void;
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, item: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  resetMenuToDefaults: () => void;

  // Cart
  cart: CartItem[];
  addToCart: (item: MenuItem, quantity?: number, instructions?: string) => void;
  removeFromCart: (itemId: string) => void;
  updateCartQuantity: (itemId: string, delta: number) => void;
  updateCartInstructions: (itemId: string, instructions: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  cartPackagingFee: number;
  cartTotal: number;

  // Orders
  orders: Order[];
  placeOrder: (scheduledTime: string, paymentMethod?: 'UPI' | 'Cash', upiTransactionRef?: string) => Order | null;
  updateOrderStatus: (orderId: string, status: OrderStatus, reason?: string) => void;
  cancelOrder: (orderId: string, reason?: string) => boolean;
  activeStudentOrder: Order | null;
  reorder: (order: Order) => void;

  // Audio Chime
  chimeEnabled: boolean;
  toggleChime: () => void;
}

const CanteenContext = createContext<CanteenContextType | undefined>(undefined);

const STORAGE_KEYS = {
  MENU: 'nbkrcn_menu_v1',
  ORDERS: 'nbkrcn_orders_v1',
  USERS: 'nbkrcn_users_v1',
  CURRENT_USER: 'nbkrcn_current_user_v1',
  CART: 'nbkrcn_cart_v1',
  CHIME: 'nbkrcn_chime_v1',
};

// Safe localStorage helper
function getStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota issues
  }
}

export const CanteenProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // State Initialization with guaranteed canteen / nbkr@2026 credentials
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const stored = getStored<UserProfile[]>(STORAGE_KEYS.USERS, []);
    if (!stored || stored.length === 0) return INITIAL_USERS;

    // Guarantee staff account has exact required credentials
    const staffIndex = stored.findIndex((u) => u.role === 'staff' || u.username === 'canteen' || u.id === 'user_staff_1');
    if (staffIndex >= 0) {
      stored[staffIndex] = {
        ...stored[staffIndex],
        username: 'canteen',
        password: 'nbkr@2026',
        role: 'staff',
      };
      return [...stored];
    } else {
      return [...stored, INITIAL_USERS[2]];
    }
  });

  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() =>
    getStored<UserProfile | null>(STORAGE_KEYS.CURRENT_USER, null)
  );
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    const stored = getStored<MenuItem[]>(STORAGE_KEYS.MENU, INITIAL_MENU_ITEMS);
    return stored.map((item) => {
      const initial = INITIAL_MENU_ITEMS.find((init) => init.id === item.id);
      return {
        ...item,
        imageUrl: item.imageUrl || initial?.imageUrl,
      };
    });
  });
  const [orders, setOrders] = useState<Order[]>(() => getStored(STORAGE_KEYS.ORDERS, INITIAL_ORDERS));
  const [cart, setCart] = useState<CartItem[]>(() => getStored(STORAGE_KEYS.CART, []));
  const [chimeEnabled, setChimeEnabled] = useState<boolean>(() => getStored(STORAGE_KEYS.CHIME, true));

  // Sync state to local storage
  useEffect(() => {
    setStored(STORAGE_KEYS.USERS, users);
  }, [users]);

  useEffect(() => {
    setStored(STORAGE_KEYS.CURRENT_USER, currentUser);
  }, [currentUser]);

  useEffect(() => {
    setStored(STORAGE_KEYS.MENU, menuItems);
  }, [menuItems]);

  useEffect(() => {
    setStored(STORAGE_KEYS.ORDERS, orders);
  }, [orders]);

  useEffect(() => {
    setStored(STORAGE_KEYS.CART, cart);
  }, [cart]);

  useEffect(() => {
    setStored(STORAGE_KEYS.CHIME, chimeEnabled);
  }, [chimeEnabled]);

  // Cloud menu hydration. If the cloud is empty, seed it from the app defaults.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const { data, error } = await supabase.from('menu_items').select('*').order('created_at', { ascending: true });
      if (cancelled || error) return;
      if (data && data.length > 0) {
        const mapped = data.map((r: any) => ({
          id: r.id, name: r.name, description: r.description || '', price: Number(r.price), category: r.category,
          isVeg: r.is_veg, availability: r.availability, stockQuantity: r.stock_quantity,
          prepTimeMinutes: r.prep_time_minutes, rating: r.rating == null ? undefined : Number(r.rating),
          iconType: r.icon_type || 'combo', accentColor: r.accent_color || '#f59e0b', imageUrl: r.image_url || undefined,
        })) as MenuItem[];
        setMenuItems(mapped);
      } else if (!error) {
        await supabase.from('menu_items').upsert(INITIAL_MENU_ITEMS.map((m) => ({
          id: m.id, name: m.name, description: m.description, price: m.price, category: m.category, is_veg: m.isVeg,
          availability: m.availability, stock_quantity: m.stockQuantity, prep_time_minutes: m.prepTimeMinutes, rating: m.rating,
          icon_type: m.iconType, accent_color: m.accentColor, image_url: m.imageUrl,
        })));
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Supabase realtime synchronization for orders and menu changes.
  useEffect(() => {
    const channel = supabase.channel('nbkrcn-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, (payload) => {
        const row: any = payload.new;
        if (!row?.id) return;
        if (payload.eventType === 'INSERT') setOrders((prev) => [{
          id: row.id, tokenNumber: row.token_number, studentId: row.student_id, studentName: row.student_name,
          studentRoll: row.student_roll, studentEmail: row.student_email, studentDept: row.student_dept, studentYear: row.student_year,
          studentPhone: row.student_phone, items: row.items || [], subtotal: Number(row.subtotal), packagingFee: Number(row.packaging_fee),
          total: Number(row.total), status: row.status, scheduledPickupTime: row.scheduled_pickup_time,
          estimatedReadyMinutes: row.estimated_ready_minutes, estimatedReadyAt: row.estimated_ready_at, paymentMethod: row.payment_method,
          paymentStatus: row.payment_status, upiId: row.upi_id, upiTransactionRef: row.upi_transaction_ref,
          createdAt: row.created_at, updatedAt: row.updated_at, rejectionReason: row.rejection_reason, cancellationReason: row.cancellation_reason,
        } as Order, ...prev.filter((o) => o.id !== row.id)]);
        if (payload.eventType === 'UPDATE') setOrders((prev) => prev.map((o) => o.id === row.id ? { ...o, status: row.status, updatedAt: row.updated_at, rejectionReason: row.rejection_reason, cancellationReason: row.cancellation_reason } : o));
      })
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, []);

  // Real-time multi-tab synchronization via BroadcastChannel
  useEffect(() => {
    if (typeof window === 'undefined' || !('BroadcastChannel' in window)) return;
    const channel = new BroadcastChannel('nbkrcn_sync_channel');

    channel.onmessage = (event) => {
      const data = event.data;
      if (!data || !data.type) return;

      if (data.type === 'NEW_ORDER') {
        setOrders((prev) => [data.order, ...prev.filter((o) => o.id !== data.order.id)]);
        // Play chime if recipient is staff or admin
        if (chimeEnabled) {
          playOrderChime();
        }
      } else if (data.type === 'UPDATE_ORDER') {
        setOrders((prev) => prev.map((o) => (o.id === data.order.id ? data.order : o)));
      } else if (data.type === 'MENU_UPDATE') {
        setMenuItems(data.menuItems);
      }
    };

    return () => {
      channel.close();
    };
  }, [chimeEnabled]);

  const broadcast = useCallback((type: string, payload: Record<string, unknown>) => {
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const channel = new BroadcastChannel('nbkrcn_sync_channel');
        channel.postMessage({ type, ...payload });
        channel.close();
      }
    } catch {
      // Fallback
    }
  }, []);

  // Check unique username availability
  const isUsernameAvailable = (username: string): boolean => {
    const clean = username.trim().toLowerCase();
    if (!clean || clean.length < 3) return false;
    if (['canteen', 'admin', 'staff', 'student', 'superadmin'].includes(clean)) return false;
    return !users.some((u) => u.username?.toLowerCase() === clean);
  };

  // Auth Operations
  const login = (
    identifier: string,
    password?: string,
    specifiedRole?: UserRole
  ): { success: boolean; message?: string } => {
    const trimmed = identifier.trim().toLowerCase();
    const enteredPass = (password || '').trim();

    // 1. Staff Sign-In (Fixed Username: canteen, Password: nbkr@2026)
    if (specifiedRole === 'staff' || trimmed === 'canteen') {
      const isStaffUsername =
        trimmed === 'canteen' ||
        trimmed === 'canteen@nbkrcn.edu.in' ||
        trimmed === 'staff@nbkrcn.edu.in';

      if (!isStaffUsername) {
        return {
          success: false,
          message: 'Invalid staff username. Canteen staff username is "canteen".',
        };
      }

      if (!enteredPass || enteredPass !== 'nbkr@2026') {
        return {
          success: false,
          message: 'Incorrect staff password. Staff password is "nbkr@2026".',
        };
      }

      const staffUser =
        users.find((u) => u.username === 'canteen') ||
        users.find((u) => u.role === 'staff') ||
        INITIAL_USERS[2];

      setCurrentUser(staffUser);
      return { success: true };
    }

    // 2. Admin Sign-In
    if (specifiedRole === 'admin' || trimmed === 'admin') {
      if (trimmed !== 'admin' && trimmed !== 'admin@nbkrcn.edu.in') {
        return { success: false, message: 'Invalid admin username.' };
      }
      if (!enteredPass || (enteredPass !== 'admin@2026' && enteredPass !== 'nbkr@2026')) {
        return { success: false, message: 'Incorrect admin password.' };
      }
      const adminUser = users.find((u) => u.username === 'admin') || INITIAL_USERS[3];
      setCurrentUser(adminUser);
      return { success: true };
    }

    // 3. Student (Customer) Sign-In
    // Can match by unique username, college email, or roll number
    const student = users.find(
      (u) =>
        u.role === 'student' &&
        ((u.username && u.username.toLowerCase() === trimmed) ||
          u.email.toLowerCase() === trimmed ||
          (u.rollNumber && u.rollNumber.toLowerCase() === trimmed))
    );

    if (!student) {
      return {
        success: false,
        message: 'No student account found with this username, email, or roll number. Please click "Create account" to register.',
      };
    }

    // Check student's own unique password
    if (!enteredPass) {
      return {
        success: false,
        message: 'Please enter your password.',
      };
    }

    const validPass = student.password || 'password123';
    if (enteredPass !== validPass) {
      return {
        success: false,
        message: 'Incorrect password for this student account. Please verify and try again.',
      };
    }

    void (async () => {
      const { data } = await supabase.auth.signInWithPassword({ email: student.email, password: enteredPass });
      if (data.user) {
        setCurrentUser({ ...student, id: data.user.id });
      }
    })();
    setCurrentUser(student);
    return { success: true };
  };

  const loginAsPreset = (role: UserRole) => {
    const target = users.find((u) => u.role === role);
    if (target) {
      setCurrentUser(target);
    } else {
      const defaultUser = INITIAL_USERS.find((u) => u.role === role) || INITIAL_USERS[0];
      setCurrentUser(defaultUser);
    }
  };

  const logout = () => {
    void supabase.auth.signOut();
    setCurrentUser(null);
  };

  const registerStudent = (
    details: Omit<UserProfile, 'id' | 'role' | 'createdAt' | 'status'>
  ): { success: boolean; message?: string } => {
    const username = (details.username || '').trim().toLowerCase();
    const email = details.email.trim().toLowerCase();

    if (!username) {
      return { success: false, message: 'Please provide a unique username.' };
    }

    if (username.length < 3) {
      return { success: false, message: 'Username must be at least 3 characters long.' };
    }

    if (['canteen', 'admin', 'staff', 'superadmin'].includes(username)) {
      return { success: false, message: `Username "${username}" is reserved. Please pick a unique student username.` };
    }

    // Uniqueness validation across registered students
    const usernameTaken = users.some((u) => u.username?.toLowerCase() === username);
    if (usernameTaken) {
      return {
        success: false,
        message: `Username "${username}" is already taken by another student. Please choose a different unique username.`,
      };
    }

    const emailTaken = users.some((u) => u.email.toLowerCase() === email);
    if (emailTaken) {
      return {
        success: false,
        message: 'An account with this college email already exists. Please sign in.',
      };
    }

    const newStudent: UserProfile = {
      ...details,
      username,
      id: `std_${Date.now()}`,
      role: 'student',
      createdAt: new Date().toISOString(),
      status: 'active',
    };

    // Create the real Supabase Auth account in the background. The local session
    // keeps the existing UI synchronous while the cloud profile is persisted.
    void (async () => {
      const { data, error } = await supabase.auth.signUp({ email, password: details.password || '' });
      if (!error && data.user) {
        await supabase.from('user_profiles').upsert({
          id: data.user.id, name: newStudent.name, email: newStudent.email, role: 'student',
          username: newStudent.username, roll_number: newStudent.rollNumber, department: newStudent.department,
          year: newStudent.year, phone: newStudent.phone, status: 'active',
        });
        setCurrentUser({ ...newStudent, id: data.user.id });
      }
    })();

    setUsers((prev) => [...prev, newStudent]);
    setCurrentUser(newStudent);
    return { success: true };
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    if (!currentUser) return;
    const refreshed = { ...currentUser, ...updated };
    setCurrentUser(refreshed);
    setUsers((prev) => prev.map((u) => (u.id === refreshed.id ? refreshed : u)));
  };

  const addStaffAccount = (name: string, email: string, role: 'staff' | 'admin') => {
    const newStaff: UserProfile = {
      id: `stf_${Date.now()}`,
      name,
      email,
      role,
      createdAt: new Date().toISOString(),
      status: 'active',
    };
    setUsers((prev) => [...prev, newStaff]);
  };

  const toggleUserStatus = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: u.status === 'inactive' ? 'active' : 'inactive' } : u))
    );
  };

  // Menu Management
  const updateItemAvailability = (id: string, availability: AvailabilityStatus) => {
    setMenuItems((prev) => {
      const updated = prev.map((item) => {
        if (item.id === id) {
          const newStock = availability === 'out_of_stock' ? 0 : item.stockQuantity === 0 ? 20 : item.stockQuantity;
          return { ...item, availability, stockQuantity: newStock };
        }
        return item;
      });
      broadcast('MENU_UPDATE', { menuItems: updated });
      return updated;
    });
  };

  const updateItemStock = (id: string, stock: number) => {
    setMenuItems((prev) => {
      const updated = prev.map((item) => {
        if (item.id === id) {
          const availability: AvailabilityStatus = stock <= 0 ? 'out_of_stock' : stock < 10 ? 'limited' : 'available';
          return { ...item, stockQuantity: Math.max(0, stock), availability };
        }
        return item;
      });
      broadcast('MENU_UPDATE', { menuItems: updated });
      return updated;
    });
  };

  const batchUpdateAvailability = (itemIds: string[], availability: AvailabilityStatus) => {
    setMenuItems((prev) => {
      const updated = prev.map((item) => {
        if (itemIds.includes(item.id)) {
          const newStock = availability === 'out_of_stock' ? 0 : item.stockQuantity === 0 ? 20 : item.stockQuantity;
          return { ...item, availability, stockQuantity: newStock };
        }
        return item;
      });
      broadcast('MENU_UPDATE', { menuItems: updated });
      return updated;
    });
  };

  const addMenuItem = (itemData: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...itemData,
      id: `item_${Date.now()}`,
    };
    setMenuItems((prev) => {
      const updated = [...prev, newItem];
      broadcast('MENU_UPDATE', { menuItems: updated });
      return updated;
    });
  };

  const updateMenuItem = (id: string, itemData: Partial<MenuItem>) => {
    setMenuItems((prev) => {
      const updated = prev.map((item) => (item.id === id ? { ...item, ...itemData } : item));
      broadcast('MENU_UPDATE', { menuItems: updated });
      return updated;
    });
  };

  const deleteMenuItem = (id: string) => {
    setMenuItems((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      broadcast('MENU_UPDATE', { menuItems: updated });
      return updated;
    });
  };

  const resetMenuToDefaults = () => {
    setMenuItems(INITIAL_MENU_ITEMS);
    broadcast('MENU_UPDATE', { menuItems: INITIAL_MENU_ITEMS });
  };

  // Cart Operations
  const addToCart = (item: MenuItem, quantity = 1, instructions = '') => {
    if (item.availability === 'out_of_stock') return;
    setCart((prev) => {
      const existing = prev.find((c) => c.menuItem.id === item.id);
      if (existing) {
        return prev.map((c) =>
          c.menuItem.id === item.id
            ? {
                ...c,
                quantity: c.quantity + quantity,
                specialInstructions: instructions || c.specialInstructions,
              }
            : c
        );
      }
      return [...prev, { menuItem: item, quantity, specialInstructions: instructions }];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((c) => c.menuItem.id !== itemId));
  };

  const updateCartQuantity = (itemId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((c) => {
          if (c.menuItem.id === itemId) {
            const newQty = c.quantity + delta;
            return newQty > 0 ? { ...c, quantity: newQty } : null;
          }
          return c;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const updateCartInstructions = (itemId: string, instructions: string) => {
    setCart((prev) =>
      prev.map((c) => (c.menuItem.id === itemId ? { ...c, specialInstructions: instructions } : c))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = useMemo(() => {
    return cart.reduce((acc, c) => acc + c.quantity, 0);
  }, [cart]);

  const cartSubtotal = useMemo(() => {
    return cart.reduce((acc, c) => acc + c.menuItem.price * c.quantity, 0);
  }, [cart]);

  const cartPackagingFee = useMemo(() => {
    return cartCount > 0 ? 5 : 0; // Flat nominal eco-packaging
  }, [cartCount]);

  const cartTotal = useMemo(() => {
    return cartSubtotal + cartPackagingFee;
  }, [cartSubtotal, cartPackagingFee]);

  // Order Placement
  const placeOrder = (
    scheduledTime: string,
    paymentMethod: 'UPI' | 'Cash' = 'UPI',
    upiTransactionRef?: string
  ): Order | null => {
    if (!currentUser || cart.length === 0) return null;

    // Generate random 4 digit token code
    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const tokenNumber = `NBK-${randomCode}`;

    // ETA calculation: base max prep time among items + 2 mins per concurrent active kitchen order
    const maxItemPrepTime = Math.max(...cart.map((c) => c.menuItem.prepTimeMinutes || 5));
    const activeKitchenOrdersCount = orders.filter((o) => o.status === 'placed' || o.status === 'accepted' || o.status === 'preparing').length;
    const estimatedMinutes = Math.min(25, maxItemPrepTime + Math.min(activeKitchenOrdersCount * 2, 10));

    const now = new Date();
    const readyAt = new Date(now.getTime() + estimatedMinutes * 60 * 1000);

    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      tokenNumber,
      studentId: currentUser.id,
      studentName: currentUser.name,
      studentRoll: currentUser.rollNumber || '21NB1A0500',
      studentEmail: currentUser.email,
      studentDept: currentUser.department || 'General',
      studentYear: currentUser.year || '3rd Year',
      studentPhone: currentUser.phone || '',
      items: cart.map((c) => ({
        menuItemId: c.menuItem.id,
        name: c.menuItem.name,
        price: c.menuItem.price,
        quantity: c.quantity,
        specialInstructions: c.specialInstructions,
      })),
      subtotal: cartSubtotal,
      packagingFee: cartPackagingFee,
      total: cartTotal,
      status: 'placed',
      scheduledPickupTime: scheduledTime,
      estimatedReadyMinutes: estimatedMinutes,
      estimatedReadyAt: readyAt.toISOString(),
      paymentMethod,
      paymentStatus: paymentMethod === 'Cash' ? 'pay_at_counter' : 'paid',
      upiId: paymentMethod === 'UPI' ? '7702479214@fam' : undefined,
      upiTransactionRef,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    // Persist the order to Supabase when the user has a real Auth session.
    void (async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const uid = sessionData.session?.user?.id;
      if (!uid) return;
      await supabase.from('orders').upsert({
        id: newOrder.id, token_number: newOrder.tokenNumber, student_id: uid, student_name: newOrder.studentName,
        student_roll: newOrder.studentRoll, student_email: newOrder.studentEmail, student_dept: newOrder.studentDept,
        student_year: newOrder.studentYear, student_phone: newOrder.studentPhone, items: newOrder.items, subtotal: newOrder.subtotal,
        packaging_fee: newOrder.packagingFee, total: newOrder.total, status: newOrder.status,
        scheduled_pickup_time: newOrder.scheduledPickupTime, estimated_ready_minutes: newOrder.estimatedReadyMinutes,
        estimated_ready_at: newOrder.estimatedReadyAt, payment_method: newOrder.paymentMethod, payment_status: newOrder.paymentStatus,
        upi_id: newOrder.upiId, upi_transaction_ref: newOrder.upiTransactionRef, created_at: newOrder.createdAt,
        updated_at: newOrder.updatedAt, rejection_reason: newOrder.rejectionReason, cancellation_reason: newOrder.cancellationReason,
      });
    })();

    // Deduct stock
    setMenuItems((prev) =>
      prev.map((item) => {
        const inCart = cart.find((c) => c.menuItem.id === item.id);
        if (inCart) {
          const updatedStock = Math.max(0, item.stockQuantity - inCart.quantity);
          const availability: AvailabilityStatus = updatedStock === 0 ? 'out_of_stock' : updatedStock < 10 ? 'limited' : 'available';
          return { ...item, stockQuantity: updatedStock, availability };
        }
        return item;
      })
    );

    // Save order
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();

    // Broadcast to staff dashboard
    broadcast('NEW_ORDER', { order: newOrder });

    // Sound chime if current view is staff
    if (chimeEnabled) {
      playOrderChime();
    }

    sendBrowserNotification(`Order Placed! Token: ${tokenNumber}`, {
      body: `Your canteen order has been received. Estimated ready in ~${estimatedMinutes} mins.`,
    });

    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus, reason?: string) => {
    setOrders((prev) => {
      const updatedList = prev.map((ord) => {
        if (ord.id === orderId) {
          const updated: Order = {
            ...ord,
            status,
            updatedAt: new Date().toISOString(),
            rejectionReason: reason || ord.rejectionReason,
          };
          broadcast('UPDATE_ORDER', { order: updated });

          // Notify student
          let title = `Order Update: ${updated.tokenNumber}`;
          let body = `Your order status is now ${status.toUpperCase()}.`;

          if (status === 'accepted') {
            body = 'The kitchen has accepted your order and will start preparing soon.';
          } else if (status === 'preparing') {
            body = 'Your food is now sizzling on the stove!';
          } else if (status === 'ready') {
            title = `Food Ready for Pickup! ${updated.tokenNumber}`;
            body = 'Your food is hot & ready! Show this token at counter to collect.';
          } else if (status === 'collected') {
            body = 'Order collected. Enjoy your meal!';
          }

          sendBrowserNotification(title, { body });
          void supabase.from('orders').update({ status: updated.status, updated_at: updated.updatedAt, rejection_reason: updated.rejectionReason, cancellation_reason: updated.cancellationReason }).eq('id', updated.id);

          return updated;
        }
        return ord;
      });
      return updatedList;
    });
  };

  const cancelOrder = (orderId: string, reason = 'Student requested cancellation'): boolean => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return false;
    // Allow cancellation only when placed or accepted
    if (order.status !== 'placed' && order.status !== 'accepted') {
      return false;
    }

    void supabase.from('orders').update({ status: 'cancelled', cancellation_reason: reason, updated_at: new Date().toISOString() }).eq('id', orderId);

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'cancelled',
              cancellationReason: reason,
              updatedAt: new Date().toISOString(),
            }
          : o
      )
    );
    return true;
  };

  const reorder = (pastOrder: Order) => {
    // Repopulate cart with available items from that order
    clearCart();
    pastOrder.items.forEach((item) => {
      const menuItem = menuItems.find((m) => m.id === item.menuItemId);
      if (menuItem && menuItem.availability !== 'out_of_stock') {
        addToCart(menuItem, item.quantity, item.specialInstructions);
      }
    });
  };

  // Find active student order
  const activeStudentOrder = useMemo(() => {
    if (!currentUser || currentUser.role !== 'student') return null;
    return (
      orders.find(
        (o) =>
          o.studentId === currentUser.id &&
          (o.status === 'placed' || o.status === 'accepted' || o.status === 'preparing' || o.status === 'ready')
      ) || null
    );
  }, [orders, currentUser]);

  const toggleChime = () => {
    setChimeEnabled((prev) => !prev);
  };

  const value = {
    currentUser,
    users,
    login,
    loginAsPreset,
    logout,
    registerStudent,
    isUsernameAvailable,
    updateProfile,
    addStaffAccount,
    toggleUserStatus,
    menuItems,
    updateItemAvailability,
    updateItemStock,
    batchUpdateAvailability,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    resetMenuToDefaults,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    updateCartInstructions,
    clearCart,
    cartCount,
    cartSubtotal,
    cartPackagingFee,
    cartTotal,
    orders,
    placeOrder,
    updateOrderStatus,
    cancelOrder,
    activeStudentOrder,
    reorder,
    chimeEnabled,
    toggleChime,
  };

  return <CanteenContext.Provider value={value}>{children}</CanteenContext.Provider>;
};

export const useCanteen = (): CanteenContextType => {
  const context = useContext(CanteenContext);
  if (!context) {
    throw new Error('useCanteen must be used within a CanteenProvider');
  }
  return context;
};
