import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Copy, Check, ExternalLink, ShieldCheck, Smartphone } from 'lucide-react';

interface CanteenUPIQRCodeProps {
  amount?: number;
  orderToken?: string;
  onPaymentSuccess?: (utr: string) => void;
  className?: string;
}

export const CanteenUPIQRCode: React.FC<CanteenUPIQRCodeProps> = ({
  amount,
  orderToken,
  className = '',
}) => {
  const upiId = '7702479214@fam';
  const recipientName = 'kull bhuvan';

  const [copied, setCopied] = useState(false);

  // Construct UPI deep-link string compliant with NPCI specification
  const upiDeepLink = amount
    ? `upi://pay?pa=${upiId}&pn=${encodeURIComponent(recipientName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(
        `NBKRCN Canteen Order ${orderToken || ''}`.trim()
      )}`
    : `upi://pay?pa=${upiId}&pn=${encodeURIComponent(recipientName)}&cu=INR`;

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`relative overflow-hidden rounded-3xl bg-[#141414] text-white p-6 sm:p-7 shadow-2xl border border-stone-800 flex flex-col items-center select-none ${className}`}
    >
      {/* Decorative Floating Money / Ambient Graphic Elements (matching uploaded image) */}
      <div className="absolute top-2 left-6 w-12 h-6 bg-emerald-500/20 rounded-md rotate-12 blur-[1px] pointer-events-none" />
      <div className="absolute top-10 right-4 w-10 h-5 bg-emerald-500/25 rounded-md -rotate-12 blur-[1px] pointer-events-none" />
      <div className="absolute bottom-12 left-4 w-16 h-8 bg-emerald-400/20 rounded-md -rotate-45 blur-[0.5px] pointer-events-none" />
      <div className="absolute bottom-6 right-8 w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 opacity-90 shadow-lg pointer-events-none flex items-center justify-center">
        <div className="w-11 h-11 rounded-full border border-amber-600/40 flex items-center justify-center font-bold text-amber-950 text-xs">
          ₹
        </div>
      </div>

      {/* Recipient Name Header */}
      <div className="text-center relative z-10 space-y-2">
        <h3 className="font-heading font-bold text-xl sm:text-2xl text-stone-100 tracking-tight">
          {recipientName}
        </h3>

        {/* UPI ID Pill Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-stone-900/90 border border-stone-700/80 shadow-inner">
          <span className="font-token font-bold text-xs sm:text-sm text-stone-200 tracking-wide">
            {upiId}
          </span>
          <button
            type="button"
            onClick={handleCopyUPI}
            title="Copy UPI ID"
            className="p-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Dynamic Amount Tag if passed */}
      {amount && (
        <div className="mt-4 px-4 py-1 rounded-xl bg-orange-600/90 text-white font-bold text-sm tabular-nums shadow-xs">
          Pay Exactly: ₹{amount}
        </div>
      )}

      {/* Center QR Code Container with FamApp Center Emblem */}
      <div className="relative mt-5 p-4 sm:p-5 bg-stone-900/90 rounded-3xl border border-stone-700/70 shadow-2xl flex items-center justify-center">
        <div className="p-3 bg-white rounded-2xl shadow-inner">
          <QRCodeSVG
            value={upiDeepLink}
            size={200}
            level="H"
            includeMargin={false}
            fgColor="#000000"
            bgColor="#FFFFFF"
            imageSettings={{
              src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="%23261C14" stroke="%23E77600" stroke-width="4"/><path d="M28 50 C40 35 60 35 72 50 C62 60 48 60 28 50 Z" fill="%23F59E0B"/><path d="M42 42 L65 32 L58 52 Z" fill="%23FBBF24"/></svg>',
              x: undefined,
              y: undefined,
              height: 38,
              width: 38,
              excavate: true,
            }}
          />
        </div>
      </div>

      {/* Direct UPI Mobile Intent CTA */}
      <div className="mt-4 w-full max-w-xs relative z-10 flex flex-col gap-2">
        <a
          href={upiDeepLink}
          className="w-full py-2.5 px-4 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-stone-950 font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
        >
          <Smartphone className="w-4 h-4" />
          <span>Pay via UPI App (GPay / PhonePe / FamApp)</span>
        </a>
      </div>

      {/* Bottom Footer Text matching FamApp */}
      <div className="mt-4 text-center relative z-10 space-y-0.5">
        <p className="text-xs text-stone-300 font-medium tracking-wide">
          Scan to pay with any UPI app
        </p>
        <div className="flex items-center justify-center gap-1.5 text-[10px] text-stone-500 font-semibold tracking-wider uppercase">
          <span>famapp</span>
          <span>·</span>
          <span>by trio</span>
        </div>
      </div>

      {/* Trust & Safe Badge */}
      <div className="mt-3 flex items-center gap-1 text-[10px] text-stone-400">
        <ShieldCheck className="w-3 h-3 text-emerald-400" />
        <span>Verified NBKRCN Canteen Official Billing Account</span>
      </div>
    </div>
  );
};
