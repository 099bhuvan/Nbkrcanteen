import React, { useState } from 'react';
import { useCanteen } from '../context/CanteenContext';
import { ShoppingBag, Bell, Volume2, VolumeX, Menu as MenuIcon, X, User } from 'lucide-react';
import { requestNotificationPermission } from '../utils/notifications';

interface NavbarProps {
  currentRoute: string;
  navigate: (route: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentRoute, navigate }) => {
  const { currentUser, logout, cartCount, loginAsPreset, chimeEnabled, toggleChime, activeStudentOrder } = useCanteen();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const handleNotificationRequest = async () => {
    const granted = await requestNotificationPermission();
    if (granted) {
      alert('Order notifications enabled! You will be alerted when food is ready.');
    }
  };

  const navLinks = () => {
    if (!currentUser) return [];

    if (currentUser.role === 'student') {
      return [
        { label: 'Menu', route: '/dashboard' },
        {
          label: 'Live Tracker',
          route: '/orders/track',
          badge: activeStudentOrder ? 'Active' : undefined,
        },
        { label: 'Order History', route: '/orders/history' },
        { label: 'Profile', route: '/profile' },
      ];
    }

    if (currentUser.role === 'staff') {
      return [
        { label: 'Live Orders Queue', route: '/staff/dashboard' },
        { label: 'Menu & Stock', route: '/staff/menu' },
      ];
    }

    // Admin
    return [
      { label: 'Live Queue', route: '/staff/dashboard' },
      { label: 'Menu & Stock', route: '/staff/menu' },
      { label: 'Analytics', route: '/admin/analytics' },
      { label: 'Users', route: '/admin/users' },
    ];
  };

  const links = navLinks();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text wordmark Brand */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => navigate(currentUser ? (currentUser.role === 'student' ? '/dashboard' : '/staff/dashboard') : '/')}
            className="text-left group cursor-pointer focus-visible:outline-hidden"
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-orange-600 flex items-center justify-center text-white font-bold text-base shadow-xs">
                N
              </div>
              <div>
                <span className="font-heading font-bold text-lg text-stone-900 tracking-tight group-hover:text-orange-600 transition-colors">
                  NBKRCN
                </span>
                <span className="hidden sm:inline-block ml-1.5 text-xs font-medium text-stone-500">
                  Smart Canteen
                </span>
              </div>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Clean text with hover underlines) */}
        {currentUser && (
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600">
            {links.map((link) => {
              const isActive = currentRoute === link.route;
              return (
                <button
                  key={link.route}
                  onClick={() => navigate(link.route)}
                  className={`relative py-1 transition-colors whitespace-nowrap cursor-pointer hover:text-stone-900 flex items-center gap-1.5 ${
                    isActive ? 'text-orange-600 font-semibold' : 'text-stone-600'
                  }`}
                >
                  <span>{link.label}</span>
                  {link.badge && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-600 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>
        )}

        {/* Zone 3: Primary Actions (Single-line controls) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {currentUser ? (
            <>
              {/* Sound chime toggle for staff/admin */}
              {(currentUser.role === 'staff' || currentUser.role === 'admin') && (
                <button
                  onClick={toggleChime}
                  title={chimeEnabled ? 'Mute Order Chime' : 'Unmute Order Chime'}
                  className={`p-2 rounded-lg text-xs transition-colors cursor-pointer border ${
                    chimeEnabled
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : 'bg-stone-100 text-stone-500 border-stone-200'
                  }`}
                >
                  {chimeEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
              )}

              {/* Notification bell button */}
              <button
                onClick={handleNotificationRequest}
                title="Enable browser notifications"
                className="hidden sm:flex p-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
              >
                <Bell className="w-4 h-4" />
              </button>

              {/* Student Cart Button */}
              {currentUser.role === 'student' && (
                <button
                  onClick={() => navigate('/cart')}
                  className="relative flex items-center gap-2 px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold rounded-lg transition-all shadow-xs active:scale-95 cursor-pointer whitespace-nowrap"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span className="hidden sm:inline">Cart</span>
                  {cartCount > 0 && (
                    <span className="px-1.5 py-0.2 bg-white text-orange-600 font-bold text-[11px] rounded-full tabular-nums">
                      {cartCount}
                    </span>
                  )}
                </button>
              )}

              {/* Role Switcher & User Menu */}
              <div className="relative">
                <button
                  onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-xs font-medium text-stone-700 transition-colors cursor-pointer"
                >
                  <User className="w-3.5 h-3.5 text-stone-500" />
                  <span className="capitalize hidden sm:inline">{currentUser.role}:</span>
                  <span className="font-semibold truncate max-w-[80px] sm:max-w-[100px]">
                    {currentUser.name.split(' ')[0]}
                  </span>
                </button>

                {roleMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-stone-200 shadow-lg py-1.5 z-50 text-xs text-stone-700 animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-3 py-2 border-b border-stone-100">
                      <p className="font-semibold text-stone-900 truncate">{currentUser.name}</p>
                      <p className="text-[11px] text-stone-500 truncate">{currentUser.email}</p>
                      <div className="mt-1 flex items-center gap-1.5 text-[10px] text-orange-600 font-medium">
                        <span className="capitalize">{currentUser.role} Account</span>
                        {currentUser.rollNumber && <span>· {currentUser.rollNumber}</span>}
                      </div>
                    </div>

                    <div className="border-t border-stone-100 mt-1 pt-1 space-y-0.5">
                      <button
                        onClick={() => {
                          setRoleMenuOpen(false);
                          navigate('/profile');
                        }}
                        className="w-full text-left px-3 py-1.5 hover:bg-stone-50 text-stone-700 cursor-pointer"
                      >
                        My Profile & Settings
                      </button>
                      <button
                        onClick={() => {
                          setRoleMenuOpen(false);
                          navigate('/orders/history');
                        }}
                        className="w-full text-left px-3 py-1.5 hover:bg-stone-50 text-stone-700 cursor-pointer"
                      >
                        Order History
                      </button>
                    </div>

                    {/* Only show station switcher for Admin role, never for Students */}
                    {currentUser.role === 'admin' && (
                      <div className="border-t border-stone-100 mt-1 pt-1">
                        <div className="px-3 py-1 text-[10px] uppercase font-semibold text-stone-400">
                          Admin Stations
                        </div>
                        <button
                          onClick={() => {
                            loginAsPreset('staff');
                            setRoleMenuOpen(false);
                            navigate('/staff/dashboard');
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-orange-50 text-stone-700 cursor-pointer"
                        >
                          Canteen Kitchen Station
                        </button>
                        <button
                          onClick={() => {
                            loginAsPreset('admin');
                            setRoleMenuOpen(false);
                            navigate('/admin/analytics');
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-orange-50 text-stone-700 cursor-pointer"
                        >
                          Admin Analytics
                        </button>
                      </div>
                    )}

                    <div className="border-t border-stone-100 mt-1 pt-1">
                      <button
                        onClick={() => {
                          logout();
                          setRoleMenuOpen(false);
                          navigate('/');
                        }}
                        className="w-full text-left px-3 py-1.5 text-red-600 hover:bg-red-50 cursor-pointer font-medium"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Mobile hamburger menu toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-stone-600 hover:text-stone-900 rounded-lg cursor-pointer"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
              </button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate('/login/student')}
                className="px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-900 cursor-pointer rounded-lg hover:bg-stone-100 transition-colors"
              >
                Student Sign-In
              </button>
              <button
                onClick={() => navigate('/login/staff')}
                className="hidden sm:inline-block px-2.5 py-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer rounded-lg hover:bg-stone-100 transition-colors"
              >
                Staff Portal
              </button>
              <button
                onClick={() => navigate('/register')}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                Register
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && currentUser && (
        <div className="md:hidden border-t border-stone-200 bg-white px-4 py-3 space-y-1">
          {links.map((link) => {
            const isActive = currentRoute === link.route;
            return (
              <button
                key={link.route}
                onClick={() => {
                  navigate(link.route);
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-sm font-medium rounded-lg flex items-center justify-between ${
                  isActive ? 'bg-orange-50 text-orange-700' : 'text-stone-600 hover:bg-stone-50'
                }`}
              >
                <span>{link.label}</span>
                {link.badge && (
                  <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                    {link.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
