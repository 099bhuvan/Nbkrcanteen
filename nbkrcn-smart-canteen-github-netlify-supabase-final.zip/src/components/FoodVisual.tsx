import React, { useState } from 'react';
import { MenuItem } from '../types';
import { Star } from 'lucide-react';

interface FoodVisualProps {
  item: MenuItem;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const FoodVisual: React.FC<FoodVisualProps> = ({ item, className = '', size = 'md' }) => {
  const [imageError, setImageError] = useState(false);

  const sizeClasses = {
    sm: 'h-16 w-16 text-2xl',
    md: 'h-44 w-full text-4xl',
    lg: 'h-56 w-full text-5xl',
  }[size];

  // Specific bespoke vector food art fallback for each item category/type
  const renderIllustration = () => {
    switch (item.iconType) {
      case 'dosa':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="44" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="2" strokeDasharray="3 3"/>
            <circle cx="50" cy="50" r="40" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="2.5"/>
            <path d="M22 68 L78 32 C82 30 84 34 81 37 L30 76 C26 79 19 72 22 68 Z" fill="#D97706" />
            <path d="M25 67 L76 34" stroke="#B45309" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M30 69 L68 44" stroke="#92400E" strokeWidth="1" strokeDasharray="2 3" />
            <circle cx="34" cy="34" r="9" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="1.5"/>
            <circle cx="34" cy="34" r="5" fill="#16A34A" fillOpacity="0.8" />
            <circle cx="64" cy="62" r="10" fill="#EA580C" stroke="#9A3412" strokeWidth="1.5"/>
          </svg>
        );

      case 'samosa':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="50" cy="55" rx="42" ry="32" fill="#F1F5F9" stroke="#E2E8F0" strokeWidth="2"/>
            <path d="M42 22 L20 62 C18 66 23 70 28 68 L62 60 C66 59 66 53 62 50 L46 23 C44 20 40 20 42 22 Z" fill="#D97706" stroke="#B45309" strokeWidth="2" strokeLinejoin="round"/>
            <path d="M22 65 Q42 66 61 60" stroke="#78350F" strokeWidth="2.5" strokeLinecap="round"/>
            <path d="M58 28 L48 56 L78 64 C82 63 84 57 80 54 L64 29 C62 26 59 26 58 28 Z" fill="#F59E0B" stroke="#B45309" strokeWidth="1.5" strokeLinejoin="round"/>
            <path d="M68 68 C64 68 62 74 68 76 C74 77 78 72 75 69 C73 67 70 67 68 68 Z" fill="#15803D" />
          </svg>
        );

      case 'biryani':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M22 46 C22 46 24 78 50 78 C76 78 78 46 78 46 Z" fill="#78350F" stroke="#451A03" strokeWidth="2"/>
            <ellipse cx="50" cy="46" rx="28" ry="8" fill="#9A3412" stroke="#451A03" strokeWidth="2"/>
            <ellipse cx="50" cy="44" rx="25" ry="12" fill="#F59E0B" />
            <path d="M42 38 L48 37" stroke="#FEF3C7" strokeWidth="2" strokeLinecap="round"/>
            <circle cx="48" cy="35" r="3" fill="#15803D" />
          </svg>
        );

      case 'thali':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="42" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="3"/>
            <ellipse cx="50" cy="52" rx="16" ry="14" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="1"/>
            <circle cx="28" cy="34" r="8" fill="#EA580C" stroke="#CBD5E1" strokeWidth="1.5"/>
            <circle cx="50" cy="24" r="8" fill="#DC2626" stroke="#CBD5E1" strokeWidth="1.5"/>
            <circle cx="72" cy="34" r="8" fill="#16A34A" stroke="#CBD5E1" strokeWidth="1.5"/>
          </svg>
        );

      case 'chai':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M36 34 L40 76 C40 78 44 80 50 80 C56 80 60 78 60 76 L64 34 Z" fill="#E2E8F0" fillOpacity="0.4" stroke="#94A3B8" strokeWidth="2"/>
            <path d="M38 44 L41 74 C41 76 44 77 50 77 C56 77 59 76 59 74 L62 44 Z" fill="#B45309"/>
            <ellipse cx="50" cy="44" rx="12" ry="3.5" fill="#D97706" stroke="#92400E" strokeWidth="1"/>
          </svg>
        );

      case 'coffee':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="50" cy="68" rx="34" ry="14" fill="#F59E0B" stroke="#B45309" strokeWidth="2"/>
            <path d="M38 32 L42 64 C42 66 45 68 50 68 C55 68 58 66 58 64 L62 32 Z" fill="#FBBF24" stroke="#B45309" strokeWidth="2"/>
            <ellipse cx="50" cy="33" rx="12" ry="4" fill="#78350F"/>
          </svg>
        );

      case 'sandwich':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M26 44 C26 28 74 28 74 44 Z" fill="#F59E0B" stroke="#B45309" strokeWidth="2"/>
            <ellipse cx="50" cy="49" rx="20" ry="6" fill="#EA580C" stroke="#9A3412" strokeWidth="1.5"/>
            <path d="M28 50 C28 62 72 62 72 50 Z" fill="#F59E0B" stroke="#B45309" strokeWidth="2"/>
          </svg>
        );

      case 'juice':
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M35 25 L40 76 C40 80 44 82 50 82 C56 82 60 80 60 76 L65 25 Z" fill="#ECFCCB" fillOpacity="0.6" stroke="#84CC16" strokeWidth="2"/>
            <circle cx="62" cy="25" r="9" fill="#A3E635" stroke="#4D7C0F" strokeWidth="1.5"/>
            <line x1="45" y1="14" x2="52" y2="76" stroke="#EF4444" strokeWidth="3" strokeLinecap="round"/>
          </svg>
        );

      default:
        return (
          <svg className="w-2/3 h-2/3 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="40" fill="#FFEDD5" stroke="#FB923C" strokeWidth="2"/>
            <path d="M50 25 L56 39 L71 40 L59 50 L63 65 L50 56 L37 65 L41 50 L29 40 L44 39 Z" fill="#F97316"/>
          </svg>
        );
    }
  };

  const hasRealImage = Boolean(item.imageUrl) && !imageError;

  return (
    <div
      className={`relative overflow-hidden flex items-center justify-center rounded-2xl bg-stone-900 border border-stone-200 group ${sizeClasses} ${className}`}
    >
      {/* Real Image or SVG Illustration Fallback */}
      {hasRealImage ? (
        <>
          <img
            src={item.imageUrl}
            alt={item.name}
            referrerPolicy="no-referrer"
            loading="lazy"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 ease-out"
          />
          {/* Subtle gradient overlay at top and bottom for text/badge legibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/30 pointer-events-none" />
        </>
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-b from-orange-50/80 to-amber-50/50">
          {renderIllustration()}
        </div>
      )}

      {/* Pure Veg Green Badge */}
      {size !== 'sm' && (
        <div className="absolute top-2.5 left-2.5 flex items-center justify-center p-0.5 bg-white/95 backdrop-blur-xs rounded-sm border border-emerald-600/50 shadow-xs z-10">
          <div className="w-3.5 h-3.5 border border-emerald-600 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
          </div>
        </div>
      )}

      {/* Rating Tag (bottom-left if medium or large) */}
      {size !== 'sm' && item.rating && (
        <div className="absolute bottom-2.5 left-2.5 px-2 py-0.5 rounded-md bg-stone-900/80 backdrop-blur-xs text-white text-[11px] font-bold flex items-center gap-1 shadow-xs z-10">
          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          <span>{item.rating.toFixed(1)}</span>
        </div>
      )}

      {/* Prep Time Tag (top-right) */}
      {size !== 'sm' && (
        <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-stone-900/80 backdrop-blur-xs text-white text-[11px] font-semibold tabular-nums shadow-xs z-10">
          ~{item.prepTimeMinutes}m
        </div>
      )}
    </div>
  );
};
